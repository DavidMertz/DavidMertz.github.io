#!/bin/bash
md5sum>_<<_____________________________________________________________

                        DAVID MERTZ, Ph.D.
                         Gnosis Software
                        99 Second Street
                     Turners Falls, MA 01376
                         mertz@gnosis.cx
                          413-863-4552

OBJECTIVES

   [07/13/00] I am currently mostly seeking ongoing consulting/project
   work; short-term contract positions in the New England area is a
   possibility also.  Travel is not a problem, but I do not wish to
   accept fulltime on-site positions outside of New England, at this
   time.

UNUSUAL NOTE

   The resume in front of you has a special form (if it has not been
   tampered with).  The resume itself should be a fully working program
   in a scripting language.  The content you are looking at should be
   preceded and followed by a few inconspicuous lines of code, such
   that if the resume file is run in the described fashion, it will
   produce a message about its own authenticity.  If the displayed
   message is a warning, someone has probably altered the resume in a
   manner I did not approve of.  A current version of the resume for
   various languages will be at http://gnosis.cx/publish/resumes/.  I
   have created versions for Perl (2 versions), Python, Bash, REXX, TCL
   (console), TCL/TK, JavaScript/HTML.  REBOL, VBScript, Postscript,
   Intercal, Haskell, Scheme, Lisp, or others may follow.  In fact, name
   an interpreted language, and I bet I can pick up enough of it fast
   enough to have a new version in a day.

   On a similar vein, I have trimmed out the experience and publication
   sections, and been comparatively terse about skills.  I have done
   quite a bit by this point, and it gets wordy.  However, check the
   same URL indicated above for an unabridged addenda.

SKILLS

 - Web-based "thin-client" development.  I have developed an
   insurance-industry training system utilizing a combination of CGI
   (Python, Apache SSI) back-ends, with DHTML (Javascript, HTML,
   PPWizard) front-end components.

 - I have published numerous articles on programming topics, and am able
   to articulate and express thoughts and knowledge clearly.  As well, I
   have an extensive publication history in non-computer academic areas
   and several years of college teaching experience.

 - Developed a certification exam for Python, used by a major testing
   company.  Background in testing and training design--and with general
   educational issues.

 - PC and client/server database systems.  I have been the primary
   programmer of commercial business systems developed in xBase
   dialects, such as Clipper 5.01-5.3, Foxpro 2.6/Windows, and
   object-oriented/event-driven Windows xBase extensions, Fivewin,
   Clip4Win, and XBase++.

 - Experienced with SQL, under DB2 and other DBMSs, including database
   design involvement.

 - Corporate development exerience; have worked with application groups
   using PVCS version control; comfortable with mainframe data
   interfaces and requirements; able to assume project lead role and
   facilitate workflow.

 - I have produced technical documentation on many programming projects,
   including database specifications, pseudo-code structures, ER and
   flow diagrams, purpose and project statements, and interface
   specifications.

 - I have developed user-friendly commercial hypertext CBTs and
   information/reference tools using a number of markup tools/
   languages, including HTML, INF, and WinHelp, as well as custom
   formats.  Experienced in creating company/unit web sites, including
   graphic-creation and look-and-feel design.

 - I have a varying levels of familiarity with a number of additional
   programming languages:  Turbo Pascal, Fortran77, Paradox PAL, Alpha
   Four, Dbase, Delphi, Basic, C/C++, REXX, Java, Python, VBA, Perl,
   PHP, TCL, Bash, Squeak Smalltalk, and others.

 - Several areas of general knowledge:  familiarity with internet and
   intranet protocols and systems, including knowledgeability to
   recommend and implement business software/hardware strategies;
   familiarity with encryption algorithms, both conventional and
   public-key, their mathematical basis, and current state-of-the art in
   commercially or freely available products.

 - I have worked with a number of operating systems, including OS/2
   Win31, Win95/8, WinNT, MacOS , BeOS, DOS, Linux, FreeBSD, Ultrix,
   386BSD, Solaris, VMS, Multics.

EXPERIENCE

 - Gnosis Software.  Jan 1998-Currently.  Consultant/Developer.

 - Tenco Media (CA/CO). April 2000-Currently.  Writer/Columnist.

 - Future Measures, Inc (MA). Jan 1999-Currently.  Consultant/Developer.

 - Lindsey Software (AR). Jul 1999-Nov 1999. Consultant/Developer.

 - Phillips Technology/MetLife (SC). Jan 1998-Dec 1998.  Senior Systems
   Analyst.

 - VMI Communications and Learning Systems (Toronto). Oct 1997-Mar
   1998.  Projects Consultant.

 - Educational Training Systems (MA). Apr 1997-Jan 1999.
   Consultant/Developer

 - Human Technology Partnership (MA).  Apr 1995-Sep 1997.  Lead
   Programmer/Developer.

   See http://gnosis.cx/publish/resumes/ for greater details.

PUBLICATIONS

   Many academic publications, and a growing body of programming
   topics for "good" (mostly online) journals.

   See http://gnosis.cx/publish/ for details.

_____________________________________________________________
if test "$(cat _)" = "e859665faeab5f060d55ba1962cbdd12  -"
   then echo "This resume seems to be healthy and intact"
else    echo "Some ne'er-do-well has altered this resume"
fi ; rm _
