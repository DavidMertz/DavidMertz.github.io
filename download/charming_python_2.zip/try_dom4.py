#---------------- File: try_dom4.py --------------------#
"""Manipulate the arrangment of nodes in a DOM object
"""
from try_dom3 import *

#-- Var 'doc' will hold the <quotations> top-level trunk
doc = dom_obj.get_childNodes()[0]

#-- Pull off all the nodes into a Python list
# (each node is a <quotation> block, or a whitespace text node)
nodes = []
while 1:
    try: node = doc.removeChild(doc.get_childNodes()[0])
    except: break
    nodes.append(node)

#-- Reverse the order of the quotations using a list method
# (we could also perform more complicated operations on the list:
# delete elements, add new ones, sort on complex criteria, etc.)
nodes.reverse()

#-- Fill 'doc' back up with our rearranged nodes
for node in nodes:
    # if second arg is None, insert is to end of list
    doc.insertBefore(node, None)

#-- Output the manipulated DOM
print dom_obj.toxml()
