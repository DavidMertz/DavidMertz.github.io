"""Convert a valid HTML document to XML
   USAGE: python try_dom1.py < infile.html > outfile.xml
"""
import sys
from xml.dom.html_builder import HtmlBuilder
from xml.dom import core

# Construct an HtmlBuilder object and feed the data to it
b = HtmlBuilder()
b.feed(sys.stdin.read())

# Get the newly-constructed document object
doc = b.document

# Output it as XML
print doc.toxml()

