#---------------- File: try_dom2.py --------------------#
"""Build a DOM instance from scratch, write it to XML
   USAGE: python try_dom2.py > outfile.xml
"""
import types
from xml.dom import core
from xml.dom.builder import Builder

# Recursive function to build DOM instance from Python instance
def object_convert(builder, inst):
    # Put entire object inside an elem w/ same name as the class.
    builder.startElement(inst.__class__.__name__)

    for attr in inst.__dict__.keys():
        if attr[0] == '_':      # Skip internal attributes
            continue
        value = getattr(inst, attr)
        if type(value) == types.InstanceType:
            # Recursively process subobjects
            object_convert(builder, value)
        else:
            # Convert anything else to string, put it in an element
            builder.startElement(attr)
            builder.text(str(value))
            builder.endElement(attr)

    builder.endElement(inst.__class__.__name__)

if __name__ == '__main__':
    # Create container classes
    class quotations: pass
    class quotation: pass

    # Create an instance, fill it with hierarchy of attributes
    inst = quotations()
    inst.title = "\nQuotations file (not quotations.dtd conformant)\n"
    inst.quot1 = quot1 = quotation()
    quot1.text = """\n'"is not a quine" is not a quine' is a quine\n"""
    quot1.source = "\nJoshua Shagam, kuro5hin.org\n"
    inst.quot2 = quot2 = quotation()
    quot2.text = "\nPython is not a democracy.  Voting doesn't help. "+\
                 "Crying may...\n"
    quot2.source = "\nGuido van Rossum, comp.lang.python\n"

    # Create the DOM Builder
    builder = Builder()
    object_convert(builder, inst)
    print builder.document.toxml()

