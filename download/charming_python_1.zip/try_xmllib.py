import xmllib, string

class MyParser(xmllib.XMLParser):
    """Crude extractor for quotations.dtd compliant XML document"""

    def __init__(self):
        xmllib.XMLParser.__init__(self)
        self.thisquote = ''

    def handle_data(self, data):
        self.thisquote = self.thisquote + data

    def syntax_error(self, message): pass

    def start_quotations(self, attrs):
        print '--- Begin Document ---'

    def unknown_starttag(self, tag, attrs):
        self.thisquote = self.thisquote + '{'

    def unknown_endtag(self, tag):
        self.thisquote = self.thisquote + '}'

    def unknown_charref(self, ref):
        self.thisquote = self.thisquote + '?'

    def unknown_entityref(self, ref):
        self.thisquote = self.thisquote + '#'

    def start_quotation(self, attrs):
        print 'QUOTATION:'

    def end_quotation(self):
        print string.join(string.split(self.thisquote[:230]))+'...',
        print '('+str(len(self.thisquote))+' bytes)\n'
        self.thisquote = ''

if __name__ == '__main__':
    parser = MyParser()
    for c in open("sample.xml").read():
        parser.feed(c)
    parser.close()

