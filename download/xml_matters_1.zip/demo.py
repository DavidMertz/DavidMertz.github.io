"""Demonstration of usage of [xml_pickle]
------------------------------------------------------------------------
For most current version of [xml_pickle], refer to:
    http://gnosis.cx/download/xml_pickle.py
------------------------------------------------------------------------"""

import xml_pickle  # import the module

# declare some classes to hold some attributes
class MyClass1: pass
class MyClass2: pass

# create a class instance, and add some basic data members to it
o = MyClass1()
o.num = 37
o.str = "Hello World"
o.lst = [1, 3.5, 2, 4+7j]

# create an instance of a different class, add some members
o2 = MyClass2()
o2.tup = ("x", "y", "z")
o2.num = 2+2j
o2.dct = { "this": "that", "spam": "eggs", 3.14: "about PI" }

# add the second instance to the first instance "container"
o.obj = o2

# print an XML representation of the container instance
xml_string = xml_pickle.XML_Pickler(o).dumps()
print xml_string

# create a new object from the XML representation
new_object = xml_pickle.XML_Pickler().loads(xml_string)
print xml_pickle.XML_Pickler(new_object).dumps()

