from sys import stdout
write = stdout.write

def push(s, lst=[]):
    if s is None: return lst
    else: lst.append(s)

def linearize():
    lst = push(None)
    lst.reverse()
    write(''.join(lst))

def showtree(node, depth=0):
    if hasattr(node, 'attr'):
        print "%2d" % depth, " "*depth, '<<'+node.type+'>>',
        if len(node.attr) > 50:
            print node.attr[:50]+'...'
        else: print node.attr
    else:
        print "%2d" %depth, "-"*depth, '<<'+node.type+'>>'
        for n in node._kids:
            showtree(n, depth+1)

def emitHTML(node):
    from typo_html import codes
    if hasattr(node, 'attr'):
        beg, end = codes[node.type]
        write(beg+node.attr+end)
    else: map(emitHTML, node._kids)

if __name__=='__main__':
    from markupbuilder import treeFromTokens
    from wordscanner import tokensFromStdin
    showtree(treeFromTokens(tokensFromStdin()))
    #emitHTML(treeFromTokens(tokensFromStdin()))

