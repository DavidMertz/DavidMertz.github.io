from spark import GenericScanner, GenericParser
from tokens import Token
from sys import stdin, stdout, argv

class WordScanner(GenericScanner):
    "Tokenize words, punctuation and markup"
    def tokenize(self, input):
        self.rv = []
        GenericScanner.tokenize(self, input)
        return self.rv
    def t_whitespace(self, s):
        r" [ \t\r\n]+ "
        self.rv.append(Token('whitespace', ' '))
    def t_alphanums(self, s):
        r" [a-zA-Z0-9]+ "
        self.rv.append(Token('alphanums', s))
    def t_safepunct(self, s):
        r' [!@#$%^&()+=|\{}:;<>,.?/"]+ '
        self.rv.append(Token('safepunct', s))
    def t_bracket(self, s):
        r' [][] '
        self.rv.append(Token('bracket', s))
    def t_asterisk(self, s):
        r' [*] '
        self.rv.append(Token('asterisk', s))
    def t_underscore(self, s):
        r' _ '
        self.rv.append(Token('underscore', s))
    def t_apostrophe(self, s):
        r" ' "
        self.rv.append(Token('apostrophe', s))
    def t_dash(self, s):
        r' - '
        self.rv.append(Token('dash', s))

class WordPlusScanner(WordScanner):
    "Enhance word/markup tokenization"
    def t_contraction(self, s):
        r" (?<=[a-zA-Z])'(am|clock|d|ll|m|re|s|t|ve) "
        self.rv.append(Token('contraction', s))
    def t_mdash(self, s):
        r' -- '
        self.rv.append(Token('mdash', s))
    def t_wordpunct(self, s):
        r' (?<=[a-zA-Z0-9])[-_](?=[a-zA-Z0-9]) '
        self.rv.append(Token('wordpunct', s))

tokenize = WordPlusScanner().tokenize
tokensFromStdin = lambda: tokenize(stdin.read())
tokensFromArgv  = lambda: tokenize(open(argv[1]).read())
tokensFromStr   = lambda s: tokenize(s)
tokensFromFname = lambda s: tokenize(open(s).read())

if __name__=='__main__':
    tokens = tokensFromStdin()
    #print ''.join([s.attr for s in tokens])
    print filter(lambda s: s<>'whitespace', tokens)

