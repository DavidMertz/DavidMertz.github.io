from spark import GenericASTBuilder
from ast import AST
from sys import stdout
nonterminal = GenericASTBuilder.nonterminal

class MarkupBuilder(GenericASTBuilder):
    "Write out HTML markup based on matched markup"
    def p_para(self, args):
        '''
        para   ::= plain
        para   ::= markup
        para   ::= para plain
        para   ::= para emph
        para   ::= para strong
        para   ::= para module
        para   ::= para code
        para   ::= para title
        plain  ::= whitespace
        plain  ::= alphanums
        plain  ::= contraction
        plain  ::= safepunct
        plain  ::= mdash
        plain  ::= wordpunct
        plain  ::= plain plain
        emph   ::= dash plain dash
        strong ::= asterisk plain asterisk
        module ::= bracket plain bracket
        code   ::= apostrophe plain apostrophe
        title  ::= underscore plain underscore
        '''
    def nonterminal(self, type_, args):
        #  Flatten AST a bit by not making nodes if only one child.
        if len(args)==1:  return args[0]
        if type_=='para': return nonterminal(self, type_, args)
        if type_=='plain':
            args[0].attr = foldtree(args[0])+foldtree(args[1])
            args[0].type = type_
            return nonterminal(self, type_, args[:1])
        phrase_node = AST(type_)
        phrase_node.attr = foldtree(args[1])
        return phrase_node

foldtree = lambda n: getattr(n,'attr',0) or ''.join(map(foldtree,n._kids))
treeFromTokens = lambda toks: MarkupBuilder(AST,'para').parse(toks)

