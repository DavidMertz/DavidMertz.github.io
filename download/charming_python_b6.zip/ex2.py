from spark import GenericScanner, GenericParser, GenericASTTraversal
from token import Token
from sys import argv

class SimpleScanner(GenericScanner):
    def __init__(self):
        GenericScanner.__init__(self)

    def tokenize(self, input):
        self.rv = []
        GenericScanner.tokenize(self, input)
        return self.rv

    def t_whitespace(self, s):
        r' \s+ '
        pass

    def t_op(self, s):
        r' \+ | \* '
        self.rv.append(Token(type=s))

    def t_number(self, s):
        r' \d+ '
        t = Token(type='number', attr=s)
        self.rv.append(t)

class FloatScanner(SimpleScanner):
    def __init__(self):
        SimpleScanner.__init__(self)

    def t_float(self, s):
        r' \d+ \. \d+ '
        t = Token(type='float', attr=s)
        self.rv.append(t)

def scan(f):
    input = f.read()
    scanner = FloatScanner()
    return scanner.tokenize(input)

scanner = FloatScanner()
print ' '.join(argv[1:])
tokens = scanner.tokenize(' '.join(argv[1:]))

print filter(lambda s: s<>'whitespace', tokens)


