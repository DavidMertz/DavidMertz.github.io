                              XMill 0.7beta

                            AT&T Corporation

Overview
--------

  XMill is a special-purpose compressor for XML data that typically achieves
  twice the compression rate over existing compressors, such as gzip.
  XMill typically compresses the XML representation of some data source
  better than conventional compression on the original data source!

  XMill is BETA release software. It is to be used at your own risk.
  Any valuable feedback and bug reports are highly appreciated and should
  be sent to Hartmut Liefke, liefke@seas.upenn.edu.

Credits
-------

  Dan Suciu, AT&T Labs Research, Florham Park, suciu@research.att.com
  Hartmut Liefke, Univ. of Pennsylvania, Philadelphia, liefke@seas.upenn.edu

Content
-------

  The full XMill distribution contains the following directories and files:

   ./COPYRIGHT.txt   - the copyright notice
   ./INSTALL.txt     - the installation manual
   ./LICENSE.txt     - the license agreement
   ./MANUAL.txt      - the user manual
   ./MINTERMS.txt    - the minimum terms agreement for redistributions of XMill
   ./README.txt      - this file

   ./unix/           - contains the UNIX (in the distribution: Linux) executables
   ./win32/          - contains the Windows 98/NT executables
   ./examples/       - contains several small XML example and '.xmill' files
                       with data specific container path and user compressors

   ./src/            - the source files of XMill
   ./bzlib/          - contains the source files for bzlib (and bzip)
   ./zlib/           - contains the source files for zlib (and minigzip)   
   ./makefile        - the make file for generating the binaries under UNIX
   ./tmp/            - contains the object files of the compilation
   ./*.dsp           - the project files for Visual C++
   ./xmill.dsw       - the workspace file for Visual C++

   ./paper           - a technical report describing the internals of XMill.

The partial distributions for Linux and Windows NT only contain the
excutables ('./unix' or './win32') and the examples ('./examples').


Documentation
-------------

  For detailed installation instructions, see the file INSTALL.txt and for
  a description of parameters of XMill, see the manual file MANUAL.txt.

  
Licensing
---------

  XMill is essentially free software.  Please read LICENSE.txt
  carefully: if you do not agree with the terms of the release, do not
  download or use this software.

  The license allows you to modify XMill and distribute the new
  software, but you must agree to certain terms.  Among others your
  license agreement must satisfy certain conditions.  To simplify this
  procedure for you, the distribution package includes MINTERMS.txt, a
  default license agreement you may use for distributing the modified
  software.


Contact Information
-------------------

  If you have questions about or problems with XMill, please contact
  Hartmut Liefke, http://www.seas.upenn.edu/~liefke,
  Email: liefke@seas.upenn.edu.
