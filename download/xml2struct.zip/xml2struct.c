/*********** xml2struct.c **********
 *  
 *   BLOCK FORMAT:
 *   1. List of open tags.  Each start tag is a single byte (w/
 *      byte value >= 0x03); this list is pushed on to the
 *      taglist stack to match corresponding close tag bytes.
 *   2. A section delimeter: 0x00 (the null byte)
 *   3. A compact representation of the block document
 *      structure, where each start tag is represented by a
 *      single byte, and the occurence of content is marked by
 *      a 0x02 byte.  A close tag is represented by a 0x01 byte,
 *      and must be back-matched to corresponding start tag.
 *   4. Another section delimeter: 0x00 (the null byte)
 *   5. The contents of all the elements indicated in the
 *      document structure schematic, grouped by element type.
 *      Each individual content item is delimited by a 0x02
 *      byte, while the start of elements of a new type is
 *      delimited by a 0x01 byte (the last not strictly needed,
 *      but it makes reversing the transformation easier).
 * 
 *   COMPRESSED BLOCK:
 *   1. 4-byte compressed block size flag
 *   2. Zlib compressed block
 * 
 *************************************/

#include <stdio.h>
#include <expat.h>
#include <string.h> 
#include <ctype.h> 
#include "stack.h"
#include "linkedlist.h"

#define MAXTAGS        253      /* Bytes 0x03-0xFF are tag abbreviations */
#define READBUFF      8192      /* How much input XML document to buffer? */
#define bool         short      /* It is nice to have bools, conceptually, */
#define false            0      /* even though ANSI C does not have them */
#define true             1
#define MAXDEPTH        64      /* Maximum nesting depth of XML doc */
#define MAXSTRUCT     8192      /* Max size of compact block structure */
#define SECTDELIM     0x00      /* Delimiter of sections */
#define TAGDELIM      0x01      /* Delimiter between tag type contents */
#define CLOSETAG      0x01      /* Close tag abbreviation in compact repr */
#define CONTDELIM     0x02      /* Delimiter between tag contents */
#define CONTSEP      "\x02"     /* Content Separator in tagContents[...] */

short findTagIndex(const char *el);
void encode_size(int size);
int readFile(const char *filename);
int getTagsFromDTD(const char *dtd, int len_dtd, char *tagList[MAXTAGS]);
int main(int argc, char *argv[]);
static void _out_chr(char c);
static void _out_stack(Charstack s, int adjust);
static void _out_contents(void);
static void _out_str(char *s);
void write_string(void);
static void flushblock(void);
static void startElement(void *cargo, const char *el, const char **attr);
static void endElement(void *cargo, const char *el);
static void characters(void *cargo, const char *ch, int len);

char *string;                   /* container for use by readFile */
int  curr_pos;                  /* offset pointer for string writes */
char Buff[READBUFF];            /* buffer for the raw file read */
int  blockcount = 0;

/***********
 * We preallocate several arrays of ints/pointers of length MAXTAGS.
 * This is slightly wasteful since most DTD's will have relatively few 
 * tags, and most array slots will be unused.  In this fixed worst case
 * for number of tags, we use slightly more than 4 kilobytes (assuming 
 * 32-bit pointer sizes.
 ***********/
int numtags;                    /* number of tags in particular DTD */
char *tagList[MAXTAGS];         /* the tags occuring in DTD/document */
short tagSizes[MAXTAGS];        /* the string length of each tag */
Stringfifo tagContents[MAXTAGS];/* contents of each tag */

int blocksize = 1000;           /* minimum (& approx total) input block */
int readsize = 0;               /* how much of block read so far */
bool compress = false;          /* should we compress blocks? */
Charstack prior_state;          /* the state when block starts */
Charstack state;                /* stack for tag state */
Charstack docstruct;            /* compact document structure */

short findTagIndex(const char *el) {
	short i;
	for (i=0; i <= numtags; i++) {
		if (strcmp(el, tagList[i]) == 0) 
			return i;			
	}	
	return -1;
}
static void _out_chr(char c) {
    string[curr_pos++] = c; 
}
static void _out_stack(Charstack s, int adjust) {
    int i;
    for (i=0; i <= s.pos; _out_chr(s.stack[i++]+adjust)); 
} 
static void _out_contents() {
    int i;
    for (i=0; i <= numtags; i++) {
        char *s;
        while ((s=popString(&tagContents[i]))) { /* (incl. CONTDELIM's) */
            _out_str(s);            /* write each tagContents[i] string */
            free(s);                /* free dangling Stringfifo string */
        }
        /* curr_pos--; */                 /* avoid unnecessay final CONTDELIM */
        _out_chr(TAGDELIM);         /* delimiter between content types */
        init_stringfifo(&tagContents[i], blocksize/numtags);
    }
 }
static void _out_str(char *s) {
    int i = 0;
    while (s[i]) {
        string[curr_pos] = s[i];
        if (curr_pos >= readsize) exit(-1);
        curr_pos++;
        i++;
    }
}
void write_string() {
    int i;
    for (i=0; i < curr_pos; printf("%c", string[i++]));
    fflush(NULL);
}
void encode_size(int size) {
    /* Given a number < 2^32, fill a 4-byte string representation */
    string[0] = (char)(size/16777216); size -= string[0]*16777216;
    string[1] = (char)(size/65536);    size -= string[1]*65536;
    string[2] = (char)(size/256);      size -= string[2]*256;
    string[3] = (char)(size);
}
static void flushblock() {
    int outlen;
	readsize *= 2;                  /* XXXXX  */
    string = malloc(readsize);      /* struct block << input block */
     if (string == NULL) {
        fprintf(stderr, "Failed to malloc() new output string\n");
        exit(-1);
    }
    curr_pos = 4;                   /* start write after size encoding */
    /* write the stack state at beginning of block (empty first time) */
    _out_stack(prior_state, 3);     /* state+3 = tag abbrev */
    stackcopy(&prior_state, &state);/* set prior_state for next flush */
    _out_chr(SECTDELIM);            /* output section delimiter */
    _out_stack(docstruct, 0);       /* output the current structure */
    stackclear(&docstruct);         /* empty docstruct for next block */
    _out_chr(SECTDELIM);            /* output section delimiter */
    _out_contents();                /* output all tagContents, in process */
                                    /* clean tagContents for next block */

    if (compress);                  /* compress the block (?) */
        /* zlib.compress(string) */
    outlen = curr_pos-4;            /* size of output w/o size header? */
    encode_size(outlen);            /* write 32-bit block size flag */
    write_string();                 /* write the final processed block */
    free(string);                   /* cleanup the memory we malloc()'d */
    readsize = 0;                   /* reset the "read so far" count */   
}
static void startElement(void *cargo, const char *el, const char **attr) {
	short shIndex = findTagIndex(el);
	char tagIndex = (char)shIndex;
 	short lastState = (short)top(&state);
	if (shIndex == -1 || shIndex >= 256) exit(-1);
 	push(&state, tagIndex);         /* push current tag */
    if (top(&docstruct) == CONTDELIM)  {
        /* leaving some content, add delim between content items */
        pushString(&tagContents[lastState], CONTSEP, 1);
    }
 	push(&docstruct, tagIndex+3);   /* add abbrev'd tag to structure */
	readsize += tagSizes[shIndex];  /* size of tag itself */
}

static void endElement(void *cargo, const char *el) {
    short shIndex = findTagIndex(el);
    short lastState = (short)pop(&state); 
                                    /* pop current tag off stack */
    push(&docstruct, TAGDELIM);     /* end tag in compact structure */
    readsize += 1+tagSizes[shIndex];/* size of tag itself */
                                    /* add delim between content items */
    pushString(&tagContents[lastState], CONTSEP, 1);
    if ((readsize > blocksize) || (state.pos == -1)) {
		/* flush structures if EITHER block size reached OR end-of-doc */
        flushblock();
    }
} 

static void characters(void *cargo, const char *ch, int len) {
 	short topState = (short)top(&state);
    pushString(&tagContents[topState], ch, (size_t)len);
    if (top(&docstruct) != CONTDELIM) {
        push(&docstruct, CONTDELIM);/* add content flag to document struct */
    }
    readsize += len;                /* read len from XML document */
} 
 
int readFile(const char *filename) {
    FILE *fp;
    int len;

    if ((fp = fopen(filename, "r")) == NULL) {
        printf("Failure opening the specified filename: %s\n", filename);
        return -1;
    }
    else {
    	if (fseek(fp, 0, SEEK_END) == 0) {
			len  = ftell(fp);
	 		fseek(fp, 0, SEEK_SET);
	 		string = malloc(len);
            if (string == NULL) {
                fprintf(stderr, "Failed to malloc() file content string\n");
                exit(-1);
            }
            
      	}
        else {
            printf("Failure determining length of filename: %s\n", filename);
            return -1;
        }
        if (fread(string, 1, len, fp) != len) {
            printf("Error reading filename (length mismatch): %s\n", filename);
            return -1;
        }
    }
    return len;
}

int getTagsFromDTD(const char *dtd, int len_dtd, char *tagList[MAXTAGS]) {
    int i;
    int decl_iter = 0;
    char ELEM[] = "<!ELEMENT";
    short sizeofElem = sizeof(ELEM);
    bool look_for_tag = false;
    bool just_seen_a_decl = true;
    char temp_tag_string[64];
    short temp_tag_pos = 0;
    short tagCount = 0;

    /* Pattern: <!ELEMENT (whitespace) tagname (whitespace) */
    for (i=0; i < len_dtd; i++) {       /* iterate through the DTD */
        if (look_for_tag) {             /* Just found "<!ELEMENT" ... */
            if (isspace(dtd[i])) {
                if (just_seen_a_decl) ; /* do nothing: init whitespace */
                else {                  /* trailing whitespace */
                    look_for_tag = false; /* back to looking for <!ELEMENT */
                    /* assure null termination of temp_tag_string */
                    temp_tag_string[temp_tag_pos] = 0x00;
                    /* add tag string to next array position */
                    tagList[tagCount] = malloc(temp_tag_pos+1);
                    if (tagList[tagCount] == NULL) {
                        fprintf(stderr, 
                                "Failed to malloc() tagList[%d]\n", tagCount);
                        exit(-1);
                    }
                    strcpy(tagList[tagCount], temp_tag_string);
                    tagSizes[tagCount] = temp_tag_pos+2;
                    tagCount++;         /* ready for next tag */
                                        /* complain before array prob */
                    if (tagCount > MAXTAGS) {    
                        printf("Error: More than MAXTAGS tags encountered");
                        return -1;
                    }
                }                       /* end else (trailing whitespace) */
            }                           /* endif (isspace) */
            else {      /* not whitespace, accum chars in tag string */
                just_seen_a_decl = false;
                temp_tag_string[temp_tag_pos++] = dtd[i];
            }                           /* end else (not whitespace) */
        }                               /* endif (look_for_tag) */
        else {  /* Look for "<!ELEMENT" announcement of next tag */
            if (decl_iter == sizeofElem-1) {
                look_for_tag = true;    /* new tag coming up */ 
                temp_tag_pos = 0;       /* temp_tag_string offset */
        	    decl_iter = 0;          /* "announcement" offset */ 
	        }
            else if (dtd[i] != ELEM[decl_iter++]) {
	            decl_iter = 0;          /* No "announcement" here */
            }
        }
    }                                   /* end for (iterate through DTD) */
    return tagCount-1;
}

int main(int argc, char *argv[]) {
    XML_Parser parser = XML_ParserCreate(NULL);
    if (! parser) {
        fprintf(stderr, "Couldn't allocate memory for parser\n");
        exit(-1);
    }
    if (argc != 3) {
      	fprintf(stderr, "Usage: xml2struct dtd_name blocksize [< xmlfile]\n");
      	exit(-1);
    }
    { /*------ Various initializations prior to actual parsing ------*/
        char *dtd_name = argv[1];
        int i, len_dtd = readFile(dtd_name);    /* Fill 'string' w/ DTD */
        blocksize = atoi(argv[2]);
        numtags = getTagsFromDTD(string, len_dtd, tagList);
        free(string);

        init_charstack(&prior_state, MAXDEPTH);
        init_charstack(&state, MAXDEPTH);
        init_charstack(&docstruct, MAXSTRUCT);

        for (i=0; i <= numtags; i++) 
            init_stringfifo(&tagContents[i], blocksize/numtags); 
    }    
    
    XML_SetElementHandler(parser, startElement, endElement);
    XML_SetCharacterDataHandler(parser, characters);

    for (;;) {
      	int done; int len;
      	len = fread(Buff, 1, READBUFF, stdin);
      	if (ferror(stdin)) {
		 	fprintf(stderr, "Read error\n");
		 	exit(-1);
      	}
      	done = feof(stdin);
      	if (! XML_Parse(parser, Buff, len, done)) {
			fprintf(stderr, "Parse error at line %d:\n%s\n",
			XML_GetCurrentLineNumber(parser),
			XML_ErrorString(XML_GetErrorCode(parser)));
	 		exit(-1);
      	}
      	if (done) break;
    }
    return 0;
}
/* End of main */

