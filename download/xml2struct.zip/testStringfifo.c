#include <stdio.h>
#include "linkedlist.h"

Stringfifo strings;

int main() {
    int i;
    char *s;
    
    init_stringfifo(&strings, 50);
    for (i=0; i < 3; i++) {
        pushString(&strings, "* Mary had ", 0);
        pushString(&strings, "* a little lamb...", 0);
        pushString(&strings, "*its fleece as white as snow, ", 0);
        pushString(&strings, "* and where Mary ", 0);
        pushString(&strings, "* went...", 0);
    }    
        pushString(&strings, 
                   "* the lamb was sure to go as well for more than 50 bytes", 0);
    while (s = popString(&strings)) printf("%s\n", s);
    return 0;
}
