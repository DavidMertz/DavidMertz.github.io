#include <stdio.h>

typedef struct charstack {
   int pos;
   int len;
   char *stack;
} Charstack;

int init_charstack(Charstack *s, int len);
void stackclear(Charstack *s);
int stackcopy(Charstack *dst, Charstack *src);
int push(Charstack *s, char c);
char pop(Charstack *s);
char top(Charstack *s);

int init_charstack(Charstack *s, int len) {
   s->pos = -1;
   s->stack = (char*)malloc(len);
   if (s->stack == NULL) return (s->len = 0);
   else 				 return (s->len = len);
}
void stackclear(Charstack *s) { 
    s->pos = -1; 
}

int stackcopy(Charstack *dst, Charstack *src) {
	int i;
	if (dst->len != src->len) 			/* error code if heterogeneous */
		return -1;
	dst->pos = src->pos;				/* copy current stack size */
	for ( i=0; i <= src->pos;           /* copy each char within curr size */
		  dst->stack[i] =  src->stack[i++] );
	return src->pos;					/* return num chars copied */
}	

int push(Charstack *s, char c) {
   if (s->pos+1 < s->len) {
      s->pos++;
      s->stack[s->pos] = c;
      return s->pos;
   }
   else return -1;
}

char pop(Charstack *s) {
   if (s->pos >= 0) {
      s->pos--;
      return s->stack[s->pos+1];
   }
   else return 0x00;
}

char top(Charstack *s) {
	return s->stack[s->pos];
}
