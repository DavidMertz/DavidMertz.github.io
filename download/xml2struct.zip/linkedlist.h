#include <stdio.h>
#include <string.h>

typedef struct stringfifo {
	struct node *head;
	struct node *tail;
    int prealloc;
} Stringfifo;

typedef struct node {
	struct node *next;
	char *string;
    int currpos;
    int strlen;
} Node;

void init_stringfifo(Stringfifo *lst, int prealloc);
void pushString(Stringfifo *lst, const char *s, size_t slen);
char *popString(Stringfifo *lst);
void _fifotoErr(const Stringfifo lst);
Node *newnode(void);

Node *newnode() {
    Node *n;
    n = (Node*)malloc(sizeof(Node));
    if (n == NULL) {
        fprintf(stderr, "Failed to malloc() new node\n");
        exit(-1);
    }
    n->string = NULL;
    n->next = NULL;
    return n;
}

void init_stringfifo(Stringfifo *lst, int prealloc) {
    if (lst->head != NULL) {
        free(lst->head);
        lst->head = NULL;
    }
    if (lst->tail != NULL) {
        free(lst->tail);
        lst->tail = NULL;
    }  
    lst->head = lst->tail = newnode(); 
    lst->prealloc = prealloc;
}

void pushString(Stringfifo *lst, const char *s, size_t slen) {
    if (s == NULL) {
        fprintf(stderr, "NULL pointer passed as source\n");
        exit(-1);
    }
    if (lst->tail == NULL) {
        fprintf(stderr, "lst->tail is NULL\n");
        exit(-1);
    }
    if (! slen) slen = strlen(s);   /* determine len if null term string */

    /* does lst->tail need to grow a string pointer and next pointer? */
    if (lst->tail->string == NULL) {
        int strlen = (lst->prealloc > slen)? lst->prealloc : slen+1;
        lst->tail->next = newnode();
        lst->tail->currpos = 0;
        lst->tail->strlen = strlen;
        lst->tail->string = (char*)malloc(strlen);
        lst->tail->string[strlen] = 0x00; 
        lst->tail->string[0] = 0x00;  
        if (lst->tail->string == NULL) {
            fprintf(stderr, "Failed to malloc() new lst->tail->string\n");
            exit(-1);
        }
    }
    /* is there room to concatenate onto currently allocated string? */
    if ( (slen + lst->tail->currpos) < lst->tail->strlen ) {
        strncpy((lst->tail->currpos+lst->tail->string), s, slen);
        /* force null termination of string at each strncpy */
        lst->tail->currpos += slen;
        lst->tail->string[lst->tail->currpos+1] = 0x00;    
    }
    /* otherwise, let's create a new node in the linked list */
    else {   
        lst->tail = lst->tail->next; 
        pushString(lst, s, slen);
    }
}

char *popString(Stringfifo *lst) {
    /* lst->head->string is NOT free()'d here; be sure to do so in caller! */
	char *s;                
	Node *oldhead;         
    if (lst == NULL) return NULL; 
    if (lst->head == NULL) {
        lst->tail = NULL;
        return NULL;
    }
    if (lst->head->string == NULL) {
        lst->tail = NULL;
        return NULL;
    }
	s = lst->head->string; 
	oldhead = lst->head;
	lst->head = lst->head->next;
    /* what does lst->next point at (NULL?) */
	free(oldhead);
	return s;		
}

void _fifotoErr(Stringfifo lst) { 
    Node *n;
    n = lst.head;
    fprintf(stderr,"<< ");
    if (n->string) 
        fprintf(stderr, "%d // ", strlen(n->string));
    if (n->next && n->next->string)
        fprintf(stderr, "%d // ", strlen(n->next->string));
    if (n->next->next && n->next->next->string)
        fprintf(stderr, "%d ", strlen(n->next->next->string));
    fprintf(stderr,">>\n");
}
