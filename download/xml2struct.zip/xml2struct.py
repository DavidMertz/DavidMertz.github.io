#!/usr/bin/python

"""
  BLOCK FORMAT:
  1. List of open tags.  Each start tag is a single byte (w/
     byte value >= 0x03); this list is pushed on to the
     taglist stack to match corresponding close tag bytes.
  2. A section delimeter: 0x00 (the null byte)
  3. A compact representation of the block document
     structure, where each start tag is represented by a
     single byte, and the occurence of content is marked by
     a 0x02 byte.  A close tag is represented by a 0x01 byte,
     and must be back-matched to corresponding start tag.
  4. Another section delimeter: 0x00 (the null byte)
  5. The contents of all the elements indicated in the
     document structure schematic, grouped by element type.
     Each individual content item is delimited by a 0x02
     byte, while the start of elements of a new type is
     delimited by a 0x01 byte (the last not strictly needed,
     but it makes reversing the transformation easier).

  COMPRESSED BLOCK:
  1. 4-byte compressed block size flag
  2. Zlib compressed block
"""
import sys
import xml.sax
from xml.sax.handler import *
import zlib

def encode_size(n):
    "Given an number < 2**32, return a 4-byte string representation"
    b1, r = divmod(n,16777216)
    b2, r = divmod(r,65536)
    b3, b4 = divmod(r,256)
    return ''.join(map(chr,[b1,b2,b3,b4]))

class StructBlockExtractor(ContentHandler):
    """Create a special structure/content form of an XML document"""
    def __init__(self, taglist, blocksize=1000, compress=1):
        if len(taglist) > 253:
            raise ValueError, "More than 253 tags encountered"
        self.taglist = taglist      # the tags occurring in DTD/document
        self.empty_contentdct()     # dictionary of content lists
        self.blocksize = blocksize  # minimum (& approx total) input block
        self.compress = compress    # should we compress blocks
        self.readsize = 0           # how much of block read so far?
        self.prior_state = []       # the state when this block started

    def empty_contentdct(self):
        self.contentdct = {}        # dictionary of content lists
        for tag in self.taglist:
            self.contentdct[tag] = []

    def flushblock(self):
        outlst = []                 # a list to hold output strings
        for name in self.prior_state:
            # write the stack state at beginning of block
            outlst.append(chr(self.taglist.index(name)+3))
        self.prior_state = self.state[:] # set prior_state for next flush
        outlst.append(chr(0))       # section delimiter 0x00
        outlst.append(''.join(self.struct))
                                    # add the current structure list
        self.struct = []            # empty document structure for next block
        outlst.append(chr(0))       # section delimiter 0x00
        for tag in self.taglist:    # Write all content lists
            tagcont = chr(2).join(self.contentdct[tag])
            tagcont = tagcont.encode('utf-8')
            outlst.append(tagcont)
            outlst.append(chr(1))   # delimiter between content types

        self.empty_contentdct()     # empty contentdct for next block
        outstr = ''.join(outlst)    # stringify the block output
        if self.compress:           # compress the block (?)
            outstr = zlib.compress(outstr)
        outlen = len(outstr)        # what size is the output block?
        sys.stdout.write(encode_size(outlen))  
                                    # write 32-bit block size flag
        sys.stdout.write(outstr)    # write the final processed block
	self.readsize = 0

    def startDocument(self):
        self.state = []             # stack for tag state
        self.newstate = 0           # flag for continuing chars in same elem
        self.struct = []            # compact document structure

    def endDocument(self):
        self.flushblock()

    def startElement(self, name, attrs):
        self.state.append(name)     # push current tag
        self.newstate = 1           # chars go to new item
                                    # single char to indicate tag
        self.struct.append(chr(self.taglist.index(name)+3))
        self.readsize += 2+len(name) # approximate size of tag itself

    def endElement(self, name):
        self.state.pop()            # pop current tag off stack
        self.newstate = 1           # chars go to new item
        self.struct.append(chr(1))  # 0x01 is endtag in struct
        self.readsize += 3+len(name)  # approximate size of tag itself
        if self.readsize > self.blocksize:
            self.flushblock()       # might have filled input block

    def characters(self, ch):
        currstate = self.state[-1]
        if self.newstate:           # either add new chars to state item
            self.contentdct[currstate].append(ch)
            self.newstate = 0
            self.struct.append(chr(2))
                                    # 0x02 content placeholder in struct
        else:                       # or append the chars to current item
            self.contentdct[currstate][-1] += ch
        self.readsize += len(ch)    # size of element contents
	
def getTagsFromDTD(dtd):
    taglist = []                    # the tags in the DTD
    if hasattr(dtd,'read'):         # file-like argument for DTD
        dtd_str = dtd.read()
    else:                           # DTD text passed in (hopefully)
        dtd_str = open(dtd).read()
    elems = dtd_str.split('<!ELEMENT')
                                    # each element (& attributes, containers)
    for elem in elems[1:]:          # exclude stuff before first element
        taglist.append(elem.split()[0])
    return taglist

if __name__ == '__main__':
    parser = xml.sax.make_parser()
    taglist = getTagsFromDTD(sys.argv[1])
    blocksize = int(sys.argv[2])
    handler = StructBlockExtractor(taglist,blocksize,compress=0)
    parser.setContentHandler(handler)
    parser.parse(sys.stdin)