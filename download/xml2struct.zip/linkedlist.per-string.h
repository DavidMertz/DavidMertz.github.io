#include <stdio.h>
#include <string.h>
#include <unistd.h>

typedef struct stringfifo {
	struct node *head;
	struct node *tail;
} Stringfifo;

typedef struct node {
	struct node *next;
	char *string;
	int slen;
} Node;

void init_stringfifo(Stringfifo *lst);
void pushString(Stringfifo *lst, const char *s, size_t slen);
char *popString(Stringfifo *lst);
void _fifotoErr(const Stringfifo lst);
Node *newnode(void);

Node *newnode() {
    Node *n;
    int addr;
    
    fprintf(stderr, "  in newnode\n");
    
    addr = malloc(sizeof(Node));

    fprintf(stderr, "  node address: %d\n", addr);
    
    n = (Node*)addr;

    if (n == NULL) {
        fprintf(stderr, "Failed to malloc() new node\n");
        exit(-1);
    }
    fprintf(stderr, "  malloc()'d a node\n");

    n->string = NULL;
    n->next = NULL;
    n->slen = 0;

    fprintf(stderr, "  bye newnode\n");

    return n;
}

void init_stringfifo(Stringfifo *lst) {
    if (lst->head != NULL) free(lst->head);
    if (lst->tail != NULL) free(lst->tail);  
    lst->head = lst->tail = newnode(); 
}

void pushString(Stringfifo *lst, const char *s, size_t slen) {
    fprintf(stderr, "in pushString\n");

    if (s == NULL) {
        fprintf(stderr, "NULL pointer passed as source\n");
        exit(-1);
    }
    if (lst->tail == NULL) {
        fprintf(stderr, "lst->tail is NULL\n");
        exit(-1);
    }
    lst->tail->next = newnode();
    if (! slen) slen = strlen(s);

    fprintf(stderr, "  try to string malloc %d\n", slen+1);

    lst->tail->string = (char*)malloc(slen+1);

    fprintf(stderr, "  did the string malloc\n");

    if (lst->tail->string == NULL) {
        fprintf(stderr, "Failed to malloc() new lst->tail->string\n");
        exit(-1);
    }
    lst->tail->string[slen] = 0x00;     /* force null termination */
    strncpy(lst->tail->string, s, slen); 
    lst->tail->slen = slen;	
    lst->tail = lst->tail->next; 

    fprintf(stderr, "bye pushString\n");

}

char *popString(Stringfifo *lst) {
    /* lst->head->string is NOT free()'d here; be sure to do so in caller! */
	char *s;                
	Node *oldhead;         
    if (lst == NULL) return NULL; 
	oldhead = lst->head;
    if (oldhead == NULL) return NULL;
	s = oldhead->string;
	lst->head = oldhead->next;
	free(oldhead);
	return s;		
}

void _fifotoErr(Stringfifo lst) { 
    Node *n;
    n = lst.head;
    fprintf(stderr, "<< %s // %s // %s>>\n", 
                    n->string, n->next->string, n->next->next->string);
}
