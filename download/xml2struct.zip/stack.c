#include "stack.h"

Charstack s1;
Charstack t1;

int main(){  
	Charstack *s, *t;
	s = &s1;
	t = &t1;
	init_charstack(s, 32);
	init_charstack(t, 64);

	push(s,'h');
	push(s,'e');
	push(s,'l');
	push(s,'l');
	push(s,'o');

	printf("--> %d\n", s->pos);

	printf("%c",pop(s));
	printf("%c",pop(s));
	printf("%c",pop(s));
	printf("%c",pop(s));
	printf("\n");

	printf("--> %d\n", s->pos);
} 
