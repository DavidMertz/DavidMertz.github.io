#!/usr/bin/python

def structblocks2xml(s, taglist):
    prior, struct, content = s.split(chr(0))
    for c in prior: print "%02x" % ord(c),
    print len(prior), `prior`
    return ""
    
    state = [taglist[ord(i)-3] for i in prior]
                                    # stack for prior tag state
    contentlist = []                # list-of-lists of content items
    for block in content.split(chr(1)):
        contents = block.split(chr(2))
        contents.reverse()          # pop off content items from end
        contentlist.append(contents)
    skeleton = []                   # templatized version of XML
    for c in struct:
        i = ord(c)
        if i >= 3:                  # start of element
            i -= 3                  # adjust for struct tag index offset
            tag = taglist[i]        # spell out the tag from taglist
            state.append(tag)       # push current tag
            skeleton.append('<%s>' % tag)
                                    # insert the element start tag
        elif i == 1:                # end of element
            tag = state.pop()       # pop current tag off stack
            skeleton.append('</%s>' % tag)
                                    # insert the element end tag
        elif i == 2:                # insert element content
            tag = state[-1]
            try:
                item = contentlist[taglist.index(tag)].pop()
                item = item.replace('&','&amp;')
            except:
                item = "MISSING"
            skeleton.append(item)   # add bare tag to indicate content
        else:
            raise ValueError, "Unexpected structure tag: ord(%d)" % i
    return ''.join(skeleton)

def decode_size(s):
    "Given a 4-byte string representation, return a number < 2**32"
    return ord(s[0])*16777216+ord(s[1])*65536+ord(s[2])*256+ord(s[3])

def flagsize_blocks(s):
    offset = 0
    blocks = []
    while offset < len(s):
        blocklen = decode_size(s[offset:offset+4])
        offset += 4
        blocks.append(s[offset:offset+blocklen])
        offset += blocklen
    return blocks

if __name__ == '__main__':
    import sys, zlib
    from xml2struct import getTagsFromDTD
    taglist = getTagsFromDTD(sys.argv[1])
    structblocks = sys.stdin.read()
    for block in flagsize_blocks(structblocks):
        #block = zlib.decompress(block)
        xml_block = structblocks2xml(block,taglist)
	sys.stdout.write(xml_block)
