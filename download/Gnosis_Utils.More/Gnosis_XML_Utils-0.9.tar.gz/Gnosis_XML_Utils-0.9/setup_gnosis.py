#!/usr/bin/env python

from distutils.core import setup

setup ( name        = "Gnosis_XML_Utils",
        version     = "0.9",
        description = "Pythonic Interfaces and Utilities for XML Documents",
        author      = "Gnosis Software",
        author_email= "mertz@gnosis.cx",
        url         = "http://gnosis.cx/download/",
        packages    = ["gnosis.xml.pickle", "gnosis.xml.pickle.ext",
                       "gnosis.xml.pickle.util", "gnosis.xml.pickle.doc",
                       "gnosis.xml.pickle.test", "gnosis", "gnosis.xml",
                      ],
        license     = "Public Domain",
      )
