"""The gnosis.xml.pickle type extension system.

Please see [..]/gnosis/xml/doc/HOWTO.extensions for details
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)",
              "David Mertz (mertz@gnosis.cx)",
             ]
from _ext import \
     _helpers_by_classtype, _helpers_by_tagname, \
     XMLP_Helper, remove_xml_helper, add_xml_helper

from helpers import *

