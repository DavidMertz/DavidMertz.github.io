from gnosis.xml.pickle.util import safe_content, safe_string, getParanoia

# hooks for adding non-builtin types.
# each dict entry is a list of chained handlers.
_helpers_by_classtype = {}
_helpers_by_tagname = {}

def get_obj_handler(obj):
    if _helpers_by_classtype.has_key(type(obj)):
        list = _helpers_by_classtype[type(obj)]
        for helper in list:
            if helper.wants_obj(obj):
                return helper
    return None

def can_handle_obj(obj):
    if obj is None:
        # rawpickle is keyed as None, which is not what the user wants
        # (this is actually handled elsewhere, but this keeps us from
        # breaking should someone shuffle the code)
        return 0
    return get_obj_handler(obj)

def obj_to_xml(obj,start_tag,close_tag):
    helper = get_obj_handler(obj)
    return helper.obj_to_xml(obj,start_tag,close_tag)

def get_xml_handler(tag,xml_str):
    if _helpers_by_tagname.has_key(tag):
        list = _helpers_by_tagname[tag]
        for helper in list:
            if helper.wants_xml(xml_str):
                return helper
    return None

def can_handle_xml(tag, xml_str):
    return get_xml_handler(tag,xml_str)

def xml_to_obj(tag, xml_str, paranoia):
    helper = get_xml_handler(tag, xml_str)
    return helper.xml_to_obj(xml_str, paranoia)

def add_xml_helper(xmlp_helper):
    "Register an XMLP_Helper object"
    # later callers are inserted before earlier callers, which is
    # right in a "late binding" sense
    try:
        _helpers_by_classtype[xmlp_helper.class_type].insert(0,xmlp_helper)
    except:
        _helpers_by_classtype[xmlp_helper.class_type] = [xmlp_helper]
    try:
        _helpers_by_tagname[xmlp_helper.tag_name].insert(0,xmlp_helper)
    except:
        _helpers_by_tagname[xmlp_helper.tag_name] = [xmlp_helper]

def remove_xml_helper(xmlp_helper):
    "De-register an XMLP_Helper object"
    list = _helpers_by_tagname[xmlp_helper.tag_name]
    list.remove(xmlp_helper)
    list = _helpers_by_classtype[xmlp_helper.class_type]
    list.remove(xmlp_helper)

# for test purposes ... (hm ... could it be useful for some reason?)
def __disable_extensions():
    global _helpers_by_classtype
    _helpers_by_classtype = {}
    for tag in _helpers_by_tagname.keys():
        # rawpickle is always on -- we have to fallback on
        # it when everything else fails
        if tag != "rawpickle":
            del _helpers_by_tagname[tag]

class XMLP_Helper:
    "Parent class for XMLP Helpers"
    # by default, only disable helpers when PARANOIA = 2
    def __init__(self, class_type, tag_name, in_body=0, paranoia=1):
        """
        class_type = ClassType that this helper handles
        tag_name = Symbolic tagname that this helper handles
        in_body = If 0, value string placed in value= attribute,
                  eg:
                       <attr ... type="foo" value="text goes here" />

                  If 1, value string placed in element body,
                  eg:
                       <attr ... type="foo"> Text goes here </attr>

                  The difference between these is purely aesthetic.

        paranoia = Maximum PARANOIA level at which to enable this
                   helper (note that PARANOIA for helpers is a
                   static concept - it doesn't matter which
                   namespace we're in, etc. Each helper is instead
                   judged to be "safe" at a given level based on
                   what the datatype can do).
        """
        if not hasattr(self,'to_xmlp'):   raise NotImplementedError
        if not hasattr(self,'from_xmlp'): raise NotImplementedError
        self.class_type = class_type
        self.tag_name = tag_name
        self.in_body = in_body
        self.paranoia = paranoia

    def obj_to_xml(self,obj,start_tag,close_tag):
        "Create an XML pickle string for an object"
        start_tag += 'type="%s"' % self.tag_name
        if self.in_body:
          o_str = safe_content(self.to_xmlp(obj))
          start_tag += '>%s' % o_str
          close_tag = close_tag.lstrip()
        else:
          o_str = safe_string(self.to_xmlp(obj))
          start_tag += ' value="%s" />\n' % o_str
          close_tag = ''
        return (start_tag,close_tag)

    def xml_to_obj(self, xml_str, paranoia=1):
        "Unpickle an object given the XML string."
        if self.paranoia < paranoia:
            from gnosis.xml.pickle import XMLUnpicklingError
            raise XMLUnpicklingError, \
                  "Cannot create type %s under this PARANOIA setting (%d)" % \
                  (self.tag_name, paranoia)
        return self.from_xmlp(xml_str)

    def wants_obj(self,obj):
        # by default, we want everything of class_type.
        # derived classes can override if they need specialization.
        # anything not wanted is passed down the line.
        return 1

    def wants_xml(self,xml_str):
        # same as wants_obj, but given the text from the XML tag/body
        return 1
