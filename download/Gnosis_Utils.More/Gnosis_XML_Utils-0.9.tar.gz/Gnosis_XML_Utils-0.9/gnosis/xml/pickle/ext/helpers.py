from gnosis.xml.pickle.ext import XMLP_Helper, add_xml_helper

#----------------------------------------------------------------------
# Create and register a helper for SRE patterns
#----------------------------------------------------------------------
import re
SRE_Pattern_type = type(re.compile(''))
class _helper_sre(XMLP_Helper):
    "Handle SREs"
    def __init__(self):
        XMLP_Helper.__init__(self,SRE_Pattern_type,"SRE",in_body=1)

    def to_xmlp(self,obj): return obj.pattern

    def from_xmlp(self,xml_str): return re.compile(xml_str)

add_xml_helper(_helper_sre())

#----------------------------------------------------------------------
# Create and register a helper for mx.DateTime patterns (if possible)
#----------------------------------------------------------------------
try:
  import mx.DateTime
  mxDateTime_type = type(mx.DateTime.localtime())
except:
  mxDateTime_type = None      # no mx.DateTime pickles allowed

class _helper_mxdatetime(XMLP_Helper):
    "Handle mxDateTime's"
    def __init__(self):
        XMLP_Helper.__init__(self,mxDateTime_type,"mxDateTime",in_body=1)

    def to_xmlp(self,obj):
        # Since we've moved this code out-of-line, we might as
        # well have a nice, readable encoding.
        # (I avoided using strftime(), for portability reasons.)
        # Pickle seconds as a float to save full precision.
        return "YMD = %d/%d/%d, HMS = %d:%d:%f" % \
                    (obj.year,obj.month,obj.day,\
                    obj.hour,obj.minute,obj.second)

    def from_xmlp(self,xml_str):
        # is this forgiving enough? :-)
        fmt = 'YMD\s*=\s*([0-9]+)\s*/\s*([0-9]+)\s*/\s*([0-9]+)\s*,\s*'
        fmt += 'HMS\s*=\s*([0-9]+)\s*:\s*([0-9]+)\s*:\s*([0-9\.]+)'
        m = re.match(fmt,xml_str)
        return apply(mx.DateTime.DateTime,map(float,m.groups()))

if mxDateTime_type:
   add_xml_helper(_helper_mxdatetime())

#----------------------------------------------------------------------
# Create and register a helper for rawpickles
#----------------------------------------------------------------------
try:    import cPickle as pickle
except: import pickle

class _helper_rawpickle(XMLP_Helper):
    "Handle rawpickles"
    def __init__(self):
        XMLP_Helper.__init__(self,None,"rawpickle",in_body=1)

    def to_xmlp(self,obj): return pickle.dumps(obj)

    # use str(xml_str) -- sometime it's unicode
    def from_xmlp(self,xml_str): return pickle.loads(str(xml_str))

add_xml_helper(_helper_rawpickle())

