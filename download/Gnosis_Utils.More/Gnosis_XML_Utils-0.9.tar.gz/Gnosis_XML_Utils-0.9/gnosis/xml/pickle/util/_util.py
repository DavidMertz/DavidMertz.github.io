import gnosis.xml.pickle
from types import *
import sys
CLASS_STORE = {}

class _EmptyClass: pass

# get my modulename (on-the-fly classes live here)
dynamic_module = _EmptyClass().__class__.__module__

#--- Helper functions for creating objects by name ---
# (these are pretty cool to have, even without xml_pickle)

def _get_class_from_locals(dict, modname, classname):
    for name in dict.keys():
        # class imported by caller
        if name == modname and type(dict[name]) is ModuleType:
            mod = dict[name]
            if hasattr(mod,classname):
                return getattr(mod,classname)
        # class defined by caller
        if name == classname and dict[name].__module__ == modname:
            return dict[name]
    return None

def get_class_from_stack(modname, classname):
    "Get a class ONLY IF already been imported or created by caller"
    st = _mini_getstack()
    for fr in st:
        k = _get_class_from_locals(fr[0].f_locals,modname,classname)
        if k: return k

def get_class_full_search(modname, classname):
    "Get a class, importing if necessary"
    __import__(modname)
    mod = sys.modules[modname]
    if hasattr(mod,classname):
        return getattr(mod,classname)
    return None

def get_class_from_store(classname):
    "Get the class from the store, if possible"
    return CLASS_STORE.get(classname, None) or \
           gnosis.xml.pickle.__dict__.get(classname,None)

def add_class_to_store(classname='', klass=None):
    "Put the class in the store (as 'classname'), return CLASS_STORE"
    if classname and klass:
        CLASS_STORE[classname] = klass
    return CLASS_STORE

def remove_class_from_store(classname):
    "Remove the classname from the store, return CLASS_STORE"
    try: del CLASS_STORE[classname]
    except: pass
    return CLASS_STORE

def get_class_from_vapor(classname):
    " Create new class from nothing"
    exec('class %s: pass' % classname)
    k = locals()[classname]
    return k

# -- get class/module names from DOM node --

def _klass(thing):
    if type(thing) is not InstanceType:
        raise ValueError, \
              "non-Instance type %s passed to _klass()" % type(thing)
    return thing.__class__.__name__

def _module(thing):
    """If thing's class is located in CLASS_STORE, was created
    from "thin-air", or lives in the "xml_pickle" namespace,
    don't write the module name to the XML stream (without these
    checks, the XML is functional, but ugly -- module names like
    "gnosis.xml.pickle.util._util")
    """
    if type(thing) is not InstanceType:
        raise ValueError, \
              "non-Instance type %s passed to _module()" % type(thing)
    klass = thing.__class__
    if klass.__module__ == dynamic_module: return None
    if klass in CLASS_STORE.values(): return None
    if klass in gnosis.xml.pickle.__dict__.values(): return None
    return thing.__class__.__module__

def safe_eval(s):
    if 0:   # Condition for malicious string in eval() block
        raise "SecurityError", \
              "Malicious string '%s' should not be eval()'d" % s
    else:
        return eval(s)

def safe_string(s):
    # markup XML entities
    s = s.replace('&', '&amp;')
    s = s.replace('<', '&lt;')
    s = s.replace('>', '&gt;')
    s = s.replace('"', '&quot;')
    s = s.replace("'", '&apos;')
    # for others, use Python style escapes
    s = repr(s)
    return s[1:-1]  # without the extra single-quotes

def unsafe_string(s):
    # for Python escapes, exec the string
    # (niggle w/ literalizing apostrophe)
    s = s.replace("'", r"\047")
    exec "s='"+s+"'"
    # XML entities (DOM does it for us)
    return s

def safe_content(s):
   "Markup XML entities only"
   s = s.replace('&', '&amp;')
   s = s.replace('<', '&lt;')
   s = s.replace('>', '&gt;')
   return s

# basically a placeholder, in case we need to add something later
def unsafe_content(s):
   # XML entities (DOM does it for us)
   return s

def subnodes(node):
    return filter(lambda n: n.nodeName<>'#text', node.childNodes)


#-------------------------------------------------------------------
# Python 2.0 doesn't have the inspect module, so we provide
# a "mini" implementation (also faster since it doesn't lookup
# unneeded info).
#
# This was cut & pasted from the real inspect module, written
# by Ka-Ping Yee <ping@lfw.org>.
#--------------------------------------------------------------------
def _mini_getstack(context=1):
    return _mini_getouterframes(_mini_currentframe().f_back, context)

def _mini_getouterframes(frame, context=1):
    framelist = []
    while frame:
        framelist.append((frame,) + (0,0,0,0,0))
        frame = frame.f_back
    return framelist

def _mini_currentframe():
    try:
        raise 'catch me'
    except:
        return sys.exc_traceback.tb_frame.f_back
# --- End of "mini" inspect module ---

