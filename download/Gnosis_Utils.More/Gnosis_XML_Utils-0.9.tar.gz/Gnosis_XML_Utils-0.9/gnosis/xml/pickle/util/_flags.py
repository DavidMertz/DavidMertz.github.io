PARANOIA = 1            # default: security model of xml_pickle-0.51
def setParanoia(val):
    global PARANOIA
    PARANOIA = val
def getParanoia(): return PARANOIA

# 0: Put refs in XML when ident objs found, instead of entire objs
# 1: never put references in XML
DEEPCOPY = 0
def setDeepCopy(val):
    global DEEPCOPY
    DEEPCOPY = val
def getDeepCopy(): return DEEPCOPY

EXCLUDE_PARENT_ATTR = 1
def setExcludeParentAttr(val):
    global EXCLUDE_PARENT_ATTR
    EXCLUDE_PARENT_ATTR = val
def getExcludeParentAttr(): return EXCLUDE_PARENT_ATTR

