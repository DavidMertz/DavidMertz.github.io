"""Store Python objects to (pickle-like) XML Documents

Please see the information at gnosis.xml.pickle.doc for
explanation of usage, design, license, and other details
"""
from gnosis.xml.pickle.util import \
     _klass, _module, _EmptyClass, subnodes, \
     safe_eval, safe_string, unsafe_string, safe_content, unsafe_content, \
     get_class_from_stack, get_class_full_search, \
     get_class_from_store, get_class_from_vapor, \
     getParanoia, getDeepCopy, getExcludeParentAttr

# Add "standard" extension types
from gnosis.xml.pickle.ext import _ext as ext

from types import *
from xml.dom import minidom

# Get appropriate array type.
try:
  from Numeric import *
  array_type = 'NumPy_array'
except ImportError:
  from array import *
  array_type = 'array'

# Define exceptions and flags
XMLPicklingError = "gnosis.xml.pickle.XMLPicklingError"
XMLUnpicklingError = "gnosis.xml.pickle.XMLUnpicklingError"

# Maintain list of object identities for multiple and cyclical references
# (also to keep temporary objects alive)
visited = {}

class XML_Pickler:
    """Framework for 'pickle to XML'.

    XML_Pickler offers a lot of flexibility in how you do your pickling.
    See the docs for examples.
    """
    def __init__(self, py_obj=None):
        if py_obj is not None:
            if type(py_obj) is InstanceType:
                self.to_pickle = py_obj
            else:
                raise XMLPicklingError, \
                      "XML_Pickler must be initialized with Instance (or None)"

    def dump(self, fh, obj=None, deepcopy=None):
        "Write the XML representation of obj to file fh."
        # If obj==None, pickle self. If deepcopy==None, getDeepCopy().
        # Admittedly, our approach requires creating whole output XML in
        # memory first, which could be large for complex object.  Maybe
        # we'll make this more efficient later.
        fh.write(self.dumps(obj,deepcopy))

    def load(self, fh, paranoia=None):
        "Load pickled object from file fh."
        # If paranoia is None, getParanoia() is used.
        global visited
        if paranoia is None: paranoia=getParanoia()
        visited = {}
        return thing_from_dom(minidom.parse(fh),
                              container=None, paranoia=paranoia)

    def dumps(self, obj=None, deepcopy=None):
        "Create the XML representation as a string."
        # If obj==None, pickle self. If deepcopy==None, getDeepCopy().
        if deepcopy is None: deepcopy = getDeepCopy()
        # here are our three forms:
        if obj is not None:             # XML_Pickler().dumps(obj)
            return _pickle_toplevel_obj(obj, deepcopy)
        elif hasattr(self,'to_pickle'): # XML_Pickler(obj).dumps()
            return _pickle_toplevel_obj(self.to_pickle, deepcopy)
        else:                           # myXML_Pickler().dumps()
            return _pickle_toplevel_obj(self, deepcopy)

    def loads(self, xml_str, paranoia=None):
        "Load a pickled object from the given XML string."
        # If paranoia is None, getParanoia() is used.
        if paranoia is None: paranoia=getParanoia()
        global visited
        visited = {}
        return thing_from_dom(minidom.parseString(xml_str),
                              container=None, paranoia=paranoia)

#-- support functions

# handle the top object -- add XML header, etc.
def _pickle_toplevel_obj(py_obj, deepcopy):
    "Store the ref id to the pickling object"
    global visited
    visited = {}
    id_ = id(py_obj)
    visited[id_] = py_obj
    # Generate the XML string
    module = _module(py_obj)
    if module: extra = 'module="%s" class="%s"' % (module,_klass(py_obj))
    else:      extra = 'class="%s"' % _klass(py_obj)

    xml_lines = ['<?xml version="1.0"?>\n',
                 '<!DOCTYPE PyObject SYSTEM "PyObjects.dtd">\n',
                 '<PyObject %s id="%s">\n' % (extra, id_)
                ]
    pickle_instance(py_obj, xml_lines, level=0, deepcopy=deepcopy)
    xml_lines.append('</PyObject>\n')
    return ''.join(xml_lines)

def pickle_instance(obj, list, level=0, deepcopy=0):
    """Pickle the given object into a <PyObject>

    Add XML tags to list. Level is indentation (for aesthetic reasons)
    """
    # concept: to pickle an object, we pickle two things:
    #
    #   1. the object attributes (the "stuff")
    #   2. initargs, if defined
    #
    # There is a twist to this -- instead of always putting the "stuff"
    # into a container, we can make the elements of "stuff" first-level attributes,
    # which gives a more natural-looking XML representation of the object.
    #
    # We only put the "stuff" into a container if we'll need to pass it
    # later as an object to __setstate__.

    # tests below are in same order as pickle.py, in case someone depends on that.
    # note we save the special __getstate__ and __getinitargs__ objects in containers
    # of the same name -- we know for sure that the object can't also have
    # data attributes of that same name

    # first, get the initargs, if present
    try:
        args = obj.__getinitargs__()
        try:
            len(args)  # must be a sequence, from pickle.py
        except:
            raise XMLPicklingError, \
                  "__getinitargs__() must return a sequence"
    except:
        args = None

    # next, decide what the "stuff" is
    try:
        stuff = obj.__getstate__()
    except:
        stuff = obj.__dict__

    # save initargs, if we have them
    if args:
        # put them in an <attr name="__getinitargs__" ...> container
        list.append(_attr_tag('__getinitargs__', args, level, deepcopy))

    # decide how to save the "stuff", depending on whether we need
    # to later grab it back as a single object
    if not hasattr(obj,'__setstate__'):
        if type(stuff) is DictType:
            # don't need it as a single object - save keys/vals as
            # first-level attributes
            for key,val in stuff.items():
                list.append(_attr_tag(key, val, level, deepcopy))
        else:
            raise XMLPicklingError, \
                  "__getstate__ must return a DictType here"
    else:
        # else, encapsulate the "stuff" in an <attr name="__getstate__" ...>
        list.append(_attr_tag('__getstate__', stuff, level, deepcopy))

def unpickle_instance(node, paranoia):
    "Take a <PyObject> DOM node and unpickle the object."
    # slurp raw thing into a an empty object
    raw = thing_from_dom(node, _EmptyClass(), paranoia)

    # same ordering as pickle.py
    # first, create pyobj as an empty object of the correct type,
    # passing initargs, if defined
    try:
        args = raw.__getinitargs__
        delattr(raw,'__getinitargs__') # don't want this in pyobj (below)
    except:
        args = None
    pyobj = obj_from_node(node, args, paranoia)

    # next, decide what "stuff" is supposed to go into pyobj
    if hasattr(raw,'__getstate__'):
        stuff = raw.__getstate__
    else:
        stuff = raw.__dict__

    # finally, decide how to get the stuff into pyobj
    if hasattr(pyobj,'__setstate__'):
        pyobj.__setstate__(stuff)
    else:
        if type(stuff) is DictType:  # must be a Dict if no __setstate__
            # see note in pickle.py/load_build() about restricted
            # execution -- do the same thing here
            try:
                pyobj.__dict__.update(stuff)
            except RuntimeError:
                for k,v in stuff.items():
                    setattr(obj, k, v)
        else:
            # subtle -- this can happen either because the class really
            # does violate the pickle protocol, or because PARANOIA was
            # set too high, and we couldn't create the real class, so
            # __setstate__ is missing (and __stateinfo__ isn't a dict)
            raise XMLUnpicklingError, \
                  "Non-DictType without setstate violates pickle protocol."+\
                  "(PARANOIA setting may be too high)"

    return pyobj

def get_node_valuetext(node):
    "Get text from node, whether in value=, or in element body."

    # we know where the text is, based on whether there is
    # a value= attribute. ie. pickler can place it in either
    # place (based on user preference) and unpickler doesn't care

    if node._attrs.has_key('value'):
        # text in tag
        ttext = node.getAttribute('value')
        return unsafe_string(ttext)
    else:
        # text in body
        node.normalize()
        try:
            btext = node.childNodes[0].nodeValue
        except:
            btext = ''
        return unsafe_content(btext)

def _save_obj_with_id(node, obj):
    id = node.getAttribute('id')
    if len(id):     # might be None, or empty - shouldn't use as key
        visited[id] = obj

def thing_from_dom(dom_node, container=None, paranoia=1):
    "Converts an [xml_pickle] DOM tree to a 'native' Python object"
    for node in subnodes(dom_node):
        if node.nodeName == "PyObject":
            container = unpickle_instance(node, paranoia)
            try:
                id = node.getAttribute('id')
                visited[id] = container
            except KeyError:
                pass

        elif node.nodeName == 'attr':
            node_type = node.getAttribute('type')
            node_name = node.getAttribute('name')

            # check refid first (if present, type is type of referenced object)
            ref_id = node.getAttribute('refid')
            if len(ref_id):  # might be empty or None
                setattr(container, node_name, visited[ref_id])
                continue

            node_valuetext = get_node_valuetext(node)

            if node_name == '__parent__' and getExcludeParentAttr():
                pass    # Do not pickle xml_objectify bookkeeping attribute
            elif node_type == 'None':
                setattr(container, node_name, None)
            elif node_type == 'numeric':
                node_val = safe_eval(node_valuetext)
                setattr(container, node_name, node_val)
            elif node_type == 'string':
                node_val = node_valuetext
                setattr(container, node_name, node_val)
            elif node_type == 'list':
                subcontainer = thing_from_dom(node, [], paranoia)
                setattr(container, node_name, subcontainer)
                _save_obj_with_id(node, subcontainer)
            elif node_type == 'tuple':      # use list then convert
                subcontainer = thing_from_dom(node, [], paranoia)
                setattr(container, node_name, tuple(subcontainer))
                _save_obj_with_id(node, subcontainer)
            elif node_type == array_type:
                subcontainer = thing_from_dom(node, [], paranoia)
                if (array_type == 'NumPy_array'):
                    subcontainer = array(subcontainer)
                else:   # need to figure out array member types to convert
                    int_val = 1
                    for item in subcontainer:
                        if type(item) == type(1.0):
                            int_val = 0
                    if int_val:
                        subcontainer = array('b',subcontainer)
                    else:
                        subcontainer = array('f',subcontainer)
                setattr(container,node_name,subcontainer)
                _save_obj_with_id(node, subcontainer)
            elif node_type == 'dict':
                subcontainer = thing_from_dom(node, {}, paranoia)
                setattr(container, node_name, subcontainer)
                _save_obj_with_id(node, subcontainer)
            elif node_type == 'PyObject':
                subcontainer = unpickle_instance(node, paranoia)
                setattr(container, node_name, subcontainer)
                _save_obj_with_id(node, subcontainer)
            elif ext.can_handle_xml(node_type,node_valuetext):
                node_val = ext.xml_to_obj(node_type, node_valuetext, paranoia)
                setattr(container,node_name,node_val)
            else:
                raise XMLUnpicklingError, "Unknown type %s" % node

        elif node.nodeName in ['item', 'key', 'val']:
            # -- About key/val nodes --
            # There *should not* be mutable types as keys, but to cover
            # all cases, elif's are defined for mutable types. Furthermore,
            # there should only ever be *one* item in any key/val list,
            # but we again rely on other validation of the XML happening.
            node_type = str(node.getAttribute('type'))

            # check refid first (if present, type is type of referenced object)
            ref_id = node.getAttribute('refid')
            # below, we set visited{} unconditionally, so there will be a
            # zero-length key (that we shouldn't use)
            if len(ref_id):
                container.append(visited[ref_id])
                continue

            node_valuetext = get_node_valuetext(node)

            if node_type == 'numeric':
                node_val = safe_eval(node_valuetext)
                container.append(node_val)
                _save_obj_with_id(node, node_val)
            elif node_type == 'string':
                node_val = node_valuetext
                container.append(node_val)
                _save_obj_with_id(node, node_val)
            elif node_type == 'None':
                container.append(None)
            elif node_type in ('list',array_type):
                subcontainer = thing_from_dom(node, [], paranoia)
                container.append(subcontainer)
                _save_obj_with_id(node, subcontainer)
            elif node_type == 'tuple':      # use list then convert
                subcontainer = thing_from_dom(node, [], paranoia)
                container.append(tuple(subcontainer))
                _save_obj_with_id(node, subcontainer)
            elif node_type == 'dict':
                subcontainer = thing_from_dom(node, {}, paranoia)
                container.append(subcontainer)
                _save_obj_with_id(node, subcontainer)
            elif node_type == 'PyObject':
                subcontainer = unpickle_instance(node, paranoia)
                container.append(subcontainer)
                _save_obj_with_id(node, subcontainer)
            elif ext.can_handle_xml(node_type,node_valuetext):
                node_val = ext.xml_to_obj(node_type, node_valuetext, paranoia)
                container.append(node_val)
                _save_obj_with_id(node, node_val)
            else:
                raise XMLUnpicklingError, "Unknown type %s" % node_type

        elif node.nodeName == 'entry':
            keyval = thing_from_dom(node, [], paranoia)
            key, val = keyval[0], keyval[1]
            container[key] = val

        else:
            raise XMLUnpicklingError, \
                  "element %s is not in PyObjects.dtd" % node.nodeName

    return container

# -- functions for dynamic object creation --

def obj_from_classtype(klass,args=None):
    """Create an object of ClassType klass.
    Calls __init__() for the new object iff args != None
    (per the standard pickle rules)."""

    # pickle protocol disallows calling __init__ on the new
    # object, unless __getinitargs__() is present
    if args:
        obj = apply(klass,args)
    else:
        obj = _EmptyClass()
        obj.__class__ = klass

    return obj

def obj_from_name(classname, modname=None, args=None, paranoia=1):
    """Given a classname, optional module name, return an object
    of type module.classname, obeying the PARANOIA rules.  Calls
    __init__(args) on the new object iff args != None, per the
    standard pickle rules.
    """
    if paranoia <= 2:                # first, try our store
        klass = get_class_from_store(classname)
        if klass:
            return obj_from_classtype(klass, args)

    if paranoia <= 0 and modname:    # next, try our caller's namespace
        klass = get_class_from_stack(modname, classname)
        if klass:
            return obj_from_classtype(klass, args)

    if paranoia <= -1 and modname:   # next, try importing the module
        klass = get_class_full_search(modname, classname)
        if klass:
            return obj_from_classtype(klass, args)

    # careful -- needs to be a fallback if any of the above fail
    if paranoia <= 1:                # finally, create from thin air
        klass = get_class_from_vapor(classname)
        # initargs don't make sense for invented classes
        return obj_from_classtype(klass, None)

    # *should* only be for paranoia == 2, but a good failsafe anyways ...
    raise XMLUnpicklingError, \
          "Cannot create class under current PARANOIA setting!"

def obj_from_node(node, args=None, paranoia=1):
    """Given a <PyObject> node, return an object of that type.

    Call __init__(args) on the new object iff args != None,
    per the standard pickle rules. Follows the PARANOIA rules.
    """
    classname = node.getAttribute('class')
    # allow <PyObject> nodes w/out module name
    # (possibly handwritten XML, XML containing "from-air" classes,
    # or classes placed in the CLASS_STORE)
    try:
        modname = node.getAttribute('module')
    except:
        modname = None  # must exist in xml_pickle namespace, or thin-air
    return obj_from_name(classname, modname, args, paranoia)

#--- Functions to create XML output tags ---
def _attr_tag(name, thing, level=0, deepcopy=0):
    start_tag = '  '*level+('<attr name="%s" ' % name)
    close_tag ='  '*level+'</attr>\n'
    return _tag_completer(start_tag, thing, close_tag, level, deepcopy)

def _item_tag(thing, level=0, deepcopy=0):
    start_tag = '  '*level+'<item '
    close_tag ='  '*level+'</item>\n'
    return _tag_completer(start_tag, thing, close_tag, level, deepcopy)

def _entry_tag(key, val, level=0, deepcopy=0):
    start_tag = '  '*level+'<entry>\n'
    close_tag = '  '*level+'</entry>\n'
    start_key = '  '*level+'  <key '
    close_key = '  '*level+'  </key>\n'
    key_block = _tag_completer(start_key, key, close_key, level+1, deepcopy)
    start_val = '  '*level+'  <val '
    close_val = '  '*level+'  </val>\n'
    val_block = _tag_completer(start_val, val, close_val, level+1, deepcopy)
    return (start_tag + key_block + val_block + close_tag)

def _tag_compound(start_tag, typename, thing, deepcopy, extra=''):
    """Make a start tag for a compound object, handling deepcopy & refs.
    Returns (start_tag,do_copy), with do_copy indicating whether a
    copy of the data is needed.
    """
    if deepcopy:
        # don't need ids in a deepcopied file (looks neater)
        start_tag += 'type="%s" %s>\n' % (typename,extra)
        return (start_tag, 1)
    else:
        if visited.get(id(thing)):
            start_tag += 'type="%s" refid="%s" />\n' % (typename,id(thing))
            return (start_tag, 0)
        else:
            start_tag += 'type="%s" id="%s" %s>\n' % (typename,id(thing),extra)
            return (start_tag, 1)

def _tag_completer(start_tag, thing, close_tag, level, deepcopy):
    tag_body = []
    if type(thing) == NoneType:
        start_tag += 'type="None" />\n'
        close_tag = ''
    # process helpers first so the user can override anything they
    # want to in interesting ways
    elif ext.can_handle_obj(thing):
        (start_tag,close_tag) = ext.obj_to_xml(thing, start_tag,
                                                           close_tag)
    elif type(thing) in [IntType, LongType, FloatType, ComplexType]:
        start_tag += 'type="numeric" value="%s" />\n' % `thing`
        close_tag = ''
    elif type(thing) in [StringType,UnicodeType]:
        thing = safe_string(thing)
        start_tag += 'type="string" value="%s" />\n' % thing
        close_tag = ''
    # General note: when we make references, set type to referenced object
    # type -- we don't need type when unpickling, but it may be useful
    # to someone reading the XML file
    elif type(thing) in [TupleType]:
        start_tag, do_copy = _tag_compound(start_tag,'tuple',thing,deepcopy)
        if do_copy:
            for item in thing:
                tag_body.append(_item_tag(item, level+1, deepcopy))
        else:
            close_tag = ''
    elif type(thing) in [ListType]:
        start_tag, do_copy = _tag_compound(start_tag,'list',thing,deepcopy)
        if do_copy:
            for item in thing:
                tag_body.append(_item_tag(item, level+1, deepcopy))
        else:
            close_tag = ''
    elif type(thing) in [ArrayType]:
        start_tag, do_copy = _tag_compound(start_tag,array_type,thing,deepcopy)
        if do_copy:
            for item in thing:
                tag_body.append(_item_tag(item, level+1, deepcopy))
        else:
            close_tag = ''
    elif type(thing) in [DictType]:
        start_tag, do_copy = _tag_compound(start_tag,'dict',thing,deepcopy)
        if do_copy:
            for key, val in thing.items():
                tag_body.append(_entry_tag(key, val, level+1, deepcopy))
        else:
            close_tag = ''
    elif type(thing) == CodeType:
        # code objects are not picklable
        start_tag += 'type="None" />\n'
        close_tag = ''
    elif type(thing) == FunctionType:
        # function objects may be not be picklable, I'm not sure.
        # Standard pickle will pickle functions defined at the top
        # level, but only their names, not their implementations
        start_tag += 'type="function" />\n' # maybe should be None?
        close_tag = ''
    elif type(thing) in [InstanceType]:
        module = _module(thing)
        if module:
            extra = 'module="%s" class="%s"' % (module, _klass(thing))
        else:
            extra = 'class="%s"' % _klass(thing)
        start_tag, do_copy = _tag_compound(start_tag, 'PyObject',
                                           thing, deepcopy, extra)
        if do_copy:
            pickle_instance(thing, tag_body, level+1, deepcopy)
        else:
            close_tag = ''
    else:
        # try using pickled value as the XML value tag.
        # rationale:  it won't be (easily) editable, but at least
        # you'll get valid XML even if your classes happen to
        # contain a few "foreign" types, and you don't feel like
        # writing a helper object (see gnosis.xml.pickle.ext for
        # how to do that)
        try:
            # we can't lookup the helper by type, since rawpickle can pickle
            # any pickleable class, and we don't have a rawpickle DOM node
            # to use to lookup the tag handler, so we use a little inside
            # information ... :-)
            helper = ext._helpers_by_tagname['rawpickle'][0]
            (start_tag,close_tag) = helper.obj_to_xml(thing,start_tag,
                                                      close_tag)
        except:
            raise XMLPicklingError, "non-handled type %s" % type(thing)

    # need to keep a ref to the object for two reasons -
    #  1. we can ref it later instead of copying it into the XML stream
    #  2. need to keep temporary objects around so their ids don't get reused

    # if DEEPCOPY, we can skip this -- reusing ids is not an issue if we
    # never look at them
    if not deepcopy:
        visited[id(thing)] = thing

    return start_tag + ''.join(tag_body) + close_tag

# pickle-compatible API, not exported by default (note we have to
# reverse the args in dump() -- we can't reverse the XML_Pickler.dump()
# args without losing functionality)

dump = lambda o,f: XML_Pickler().dump(f,o)
dumps = XML_Pickler().dumps
loads = XML_Pickler().loads
load = XML_Pickler().load

