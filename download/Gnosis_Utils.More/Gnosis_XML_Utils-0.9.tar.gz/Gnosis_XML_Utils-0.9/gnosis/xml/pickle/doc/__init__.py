from _doc import \
     __doc__, __version__, __author__,  __thanks_to__, \
     __copyright__, __history__, __todo__

