"""Store Python objects to (pickle-like) XML Documents

Note 0:

    See http://gnosis.cx/publish/programming/xml_matters_1.txt
    for a detailed discussion of this module.  An updated
    discussion of changes in the module is at
    http://gnosis.cx/publish/programming/xml_matters_11.txt.

    Some enhancements have been contributed by various users,
    please see the __history__ for details.  Some enhancements
    may go beyond what is discussed in the referenced article.

Usage:

    xml_pickle offers quite a few ways to perform pickling,
    so you can pick and choose at your convenience.

    # By inheritence
    from xml_pickle import XML_Pickler
    class MyClass(XML_Pickler):
    # create some behavior and attributes for MyClass...
    o1 = MyClass()
    # o knows how to dump itself
    xml_str = o.dumps()
    o2 = MyClass()
    o2.loads(xml_str)

    # With inline instantiation
    from xml_pickle import XML_Pickler
    o1 = DataClass()
    # ...assign attribute values to o1...
    o1 = XML_Pickler(o1)
    # this o1 also knows how to dump itself
    xml_str = o1.dumps()
    o2 = XML_Pickler().loads(xml_str)

    # Another way to do inline instantiation
    from xml_pickle import XML_Pickler
    o1 = DataClass()
    # ...assign attribute values to o1...
    xml_str = XML_Pickler().dumps(o1)
    o2 = XML_Pickler().loads(xml_str)

    # Or, inline, the way pickle does it
    xml_str = xml_pickle.dumps(obj)
    o2 = xml_pickle.loads(xml_str)

Security:

    As with all things, there is a tradeoff between security
    and convenience when using xml_pickle. xml_pickle is
    meant to be "secure by default". This means, however,
    that the user familiar with the standard pickle module
    won't always get the expected behavior. The following
    text explains the xml_pickle security model.

    (For the impatient, the following code will give decent
     security with the "expected" pickle behavior:
       from gnosis.xml.pickle.util import setParanoia
       setParanoia(0)

    The following priority list is used during unpickling
    when xml_pickle needs to create a class:

       1. Get class from CLASS_STORE, or create on-the-fly.
       2. Get class from a module the caller has imported
       3. Get class from a module we can find in sys.path.

    These map in a straightforward way to PARANOIA levels:

    PARANOIA = 2: "extreme paranoia"

       XML_Pickler may only instantiate classes that have
       been explicity placed in the xml_pickle CLASS_STORE.

    PARANOIA = 1: "airtight"

       In addition to the above, XML_Pickler may create
       classes on-the-fly if they aren't in the xml_pickle
       namespace. (This is safe, because the classes can only
       contain data.)

    PARANOIA = 0: "good enough"

       In addition to the above, XML_Pickler may also
       instantiate classes that the caller has imported.

    PARANOIA = -1: "free-for-all"

       All of the above, plus XML_Pickler is allowed
       to import modules itself.

    See "test_paranoia.py" for numerous examples.

Classes:

    PyObject
    XML_Pickler

Functions:

    thing_from_dom(dom_node, container)
    obj_from_node(node)
    subnodes(node)
    _attr_tag(...)
    _item_tag(...)
    _entry_tag(...)
    _tag_completer(...)
    _klass(...)
    safe_eval(s)
    safe_string(s)
    unsafe_string(s)

Compatibility:

   Requires Python 2.0 and up, however, the PyXML package included
   in Python 2.0 is too old. You'll have to install a newer version
   (at least 0.6.1) from http://pyxml.sourceforge.net/topics/download.html

"""
__version__ = "$Revision: 0.70 $"
__author__=["David Mertz (mertz@gnosis.cx)",]
__thanks_to__=["Grant Munsey (gmunsey@Adobe.COM)",
               "Keith J. Farmer (deoradh@yahoo.com)",
               "Anthony Baxter (anthony@interlink.com.au)",
               "Joshua Macy (j_amused@yahoo.com)",
               "Curtis Jensen (cjensen@bioeng.ucsd.edu)",
               "Joe Kraska (jkraska@bbn.com)",
               "Chip Salzenberg (chip@pobox.com)",
               "Francesc Alted (falted@imk.es)",
               "Frank McIngvale (frankm@hiwaay.net)",
              ]
__copyright__="""
    This file is released to the public domain.  I (dqm) would
    appreciate it if you choose to keep derived works under terms
    that promote freedom, but obviously am giving up any rights
    to compel such.
"""

__history__="""
    0.1    Initial version

    0.22   Compatible with PyXML 0.52

    0.30   Compatible with PyXML 0.61+

    0.40   Joshua Macy added several worthwhile things.  This
           version is compatibility with Python 2.1 (and 2.0),
           assuming nothing changes between the beta and release.

           More importantly, Joshua added checks for cyclical
           references and for multiple bindings of identical
           objects.  Previously, xml_pickle effectively forced a
           deep copy; for example:

             obj.a = aDict
             obj.b = aDict
             obj.b is obj.a   # True
             ... pickle then restore ...
             obj.a is obj.b   # False

           With version 0.40, object identity is preserved across
           pickling.

    0.45   Finally added Curtis Jensen's enhancements to use NumPy
           array type.

    0.46   Joe Kraska pointed out referential inconsistencies in
           cyclical references, and provided changes (OK'd by
           Joshua Macy, who did the referential code to start
           with).

    0.47   Improvement of the '_tag_completer()' flow control
           in case of referential objects (consistent fall-
           through to single 'return' statement.

    0.48   Modified string concatenation strategy to more
           efficiently emit large XML documents (i.e. orders of
           magnitude better; specifically, O(n) rather than
           O(n^2))

    0.49   Chip Salzenberg corrected a sloppy typo in the code
           for outputting Unicode strings.

    0.50   Francesc Alted noticed a problem with pickling
           [xml_objectify] objects.  A narrow solution to the
           problem is to a avoid pickling the special
           '.__parent__' attribute that the EXPAT option
           in 'XML_Objectify()' uses.  A better solution to the
           broader issue of upward cyclical reference might be
           provided later.

    0.51   Frank McIngvale contributed the addition of mxDateTime to
           pickleable types

    0.60   Frank McIngvale added a large number of improvements and
           extensions to the system (with a bit of advice and
           help from David Mertz along the way):

           - Simplified minidom.parse call (dqm)

           - Pickle compiled SREs.

           - Before bailing out on unknown objects, try saving
             them in their pickled form (type="rawpickle").

           - All types can read/store their value either in the
             element body or the tag.

           - Changes for Python 2.2 compatibility:
                 dir() changed
                 node.attributes[tuple] stopped working
                 more portable test for SRE type

           - Added a generalized extension system (non-builtins
             moved to xml_pickle_ext, except for NumPy, since it
             acts as a builtin).  Made mxDateTime format better,
             since code is out-of-line now (doesn't have to be so
             clever).

           - Refactored XML_Pickle to eliminate recursion
             problem, and removed unneeded PyObject template
             class.

           - Added XML_Pickle().dumps(object) form, and
             pickle-compatible inline
             dump(),dumps(),load(),loads() forms (added __all__
             so these aren't auto-imported).

           - XML_Pickle is now more flexible about how it loads
             classes, and can restore full class functionality
             (just like pickle does).  However, as this could
             present security concerns, the PARANOIA setting was
             created - see docs.

           - Full __getstate__()/__setstate__() support, as well
             as __getinitargs__ (i.e. we're now compatible with
             the regular pickle protocol).

           - Handle all types as key/val/items, and fixed ref
             handling of key/val/items.  Catch unknown types in
             both elif blocks.

           - Fixed visited{} handling to properly keep temporary
             object from being reused.

           - Added DEEPCOPY to provide pre-0.40 behavior if
             desired.

           - Implemented dqm's suggestion that ref's keep the
             referenced typename, for better readibility and to
             make it easier for external tools to parse the XML
             (unfortunately, xml_pickle <= 0.51 won't be able to
             read these pickles -- we can still read old pickles,
             though).

    0.70   Module refactored into a package.  Should make
           maintenance and further improvements easier.  Much
           extra documentation and test cases now included with
           package.

"""
__todo__ = """
"""

