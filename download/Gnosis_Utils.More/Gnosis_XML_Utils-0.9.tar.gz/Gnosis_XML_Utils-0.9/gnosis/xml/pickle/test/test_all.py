import os,sys

# use same python that we're running under
py = sys.executable

tests = ['test_bltin.py','test_mixin.py', 'test_paranoia.py','test_rawp_sre.py',
         'test_re.py', 'test_init.py', 'test_compat.py', 'test_ref.py',
         'test_override.py', 'test_getstate.py','test_basic.py',
         'test_modnames.py']

# if mx.DateTime installed, add those tests
try:
    import mx.DateTime
    tests.append('test_mx.py')
    tests.append('test_rawp_mx.py')
except:
    print "** OMITTING test_mx.py & test_rawp_mx.py"

# see if random works
try:
    import random
    r = random.Random()
    tests.append('test_setstate.py')
except:
    print "** OMITTING test_setstate.py"

# see if Numeric installed
try:
    import Numeric
    tests.append('test_numpy.py')
except:
    print "** OMITTING test_numpy.py"   

tout = 'TESTS.OUT-%s' % os.path.split(py)[-1]
os.system("rm -f %s; touch %s" %(tout,tout))

for test in tests:
    print "Running %s" % test
    os.system("echo \"** %s %s **\" >> %s" % (py,test,tout))
    r = os.system("%s %s >> %s"%(py,test,tout))
    if r != 0:
        print "***ERROR***"
        sys.exit(1)

