"Show how you can override builtin type handlers  --fpm"

import gnosis.xml.pickle as xml_pickle
import gnosis.xml.pickle.ext as xml_pickle_ext
from gnosis.xml.pickle.ext import XMLP_Helper
from gnosis.xml.pickle.util import setParanoia

from types import *
from UserList import UserList

class mystring(XMLP_Helper):

    def to_xmlp(self,obj):
        print "** mystring.to_xmlp()"
        return obj

    def from_xmlp(self,xml_str):
        print "** mystring.from_xmlp()"
        return str(xml_str)

# so it can pull in our imports
setParanoia(0)

# test1 -- use our custom handler to pickle & unpickle
# (here we fold two types to a single tagname)

my1 = mystring(StringType,"MyString",1,1)
my2 = mystring(UnicodeType,"MyString",1,1)

xml_pickle_ext.add_xml_helper(my1)
xml_pickle_ext.add_xml_helper(my2)

u = UserList(['aaa','bbb','ccc'])
print u

x = xml_pickle.dumps(u)
print x
del u

z = xml_pickle.loads(x)
print z

# remove custom handlers
xml_pickle_ext.remove_xml_helper(my1)
xml_pickle_ext.remove_xml_helper(my2)

#
# test 2 -- custom pickler, but builtin unpickler
#

# use same tagname as builtin so builtin can unpickle it
# (put text in body, even though builtin puts it in
# the value= ... just to show that builtin can find it either way)

my1 = mystring(StringType,"string",1,1)
my2 = mystring(UnicodeType,"string",1,1)

xml_pickle_ext.add_xml_helper(my1)
xml_pickle_ext.add_xml_helper(my2)

u = UserList(['aaa','bbb','ccc'])
print u

x = xml_pickle.dumps(u)
print x
del u

# remove custom helpers before unpickling
xml_pickle_ext.remove_xml_helper(my1)
xml_pickle_ext.remove_xml_helper(my2)

# now the builtin is doing the unpickling
z = xml_pickle.loads(x)
print z

# test 3
#
# show how type handlers can be chained together for
# neat purposes (though this example is pretty useless :-)
#
# mynumlist handles lists of integers and pickles them as "n,n,n,n"
# mycharlist does the same for single-char strings
#
# otherwise, the ListType builtin handles the list

class mynumlist(XMLP_Helper):

    def to_xmlp(self,obj):
        t = '%d'%obj[0]
        for i in obj[1:]:
            t = t + ',%d'%i
        return t

    def from_xmlp(self,xml_str):
        l = map(int,xml_str.split(','))
        return l

    def wants_obj(self,obj):
        # I only want lists of integers
        for i in obj:
            if type(i) is not IntType:
                return 0

        return 1

class mycharlist(XMLP_Helper):

    def to_xmlp(self,obj):
        t = '%s'%obj[0]
        for i in obj[1:]:
            t = t + ',%s'%i
        return t

    def from_xmlp(self,xml_str):
        l = xml_str.split(',')
        return l

    def wants_obj(self,obj):
        # I only want lists of single chars
        for i in obj:
            if type(i) is not StringType or \
               len(i) != 1:
                return 0

        return 1

# unlike test#1 (folding multiple types -> one tag), here
# we "explode" one type to multiple tags, so we can
# make different XML representations based on object content

my1 = mynumlist(ListType,"NumList",1,1)
my2 = mycharlist(ListType,"CharList",1,1)

xml_pickle_ext.add_xml_helper(my1)
xml_pickle_ext.add_xml_helper(my2)

u = UserList([[1,2,3],['mmm','nnn','ooo'],['a','b','c'],[4.1,5.2,6.3]])
print u
x = xml_pickle.dumps(u)
print x
del u

g = xml_pickle.loads(x)
print g

