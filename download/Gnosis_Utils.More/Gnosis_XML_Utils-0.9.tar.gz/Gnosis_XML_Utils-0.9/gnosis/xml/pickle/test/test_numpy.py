
import gnosis.xml.pickle as xml_pickle
import Numeric

class foo: pass

f = foo()

f.a = Numeric.array([1,2,3,4])
f.b = Numeric.array([1.2,2.3,3.4,4.5])

a = Numeric.array([6,7,8,9])

# make sure refs work
f.l = [a,a,a]

f.d = {'One':a,'Two':Numeric.array([10,11,12])}
f.e = f.d['Two']

print f.a, f.b, f.l

x = xml_pickle.dumps(f)
print x

del f

g = xml_pickle.loads(x)
print g.a,g.b,g.l,g.d,g.e

