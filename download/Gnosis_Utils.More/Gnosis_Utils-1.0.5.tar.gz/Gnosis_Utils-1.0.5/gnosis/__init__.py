import string
from os import sep
s = string
d = s.join(s.split(__file__, sep)[:-1], sep)+sep
_ = lambda f: s.rstrip(open(d+f).read())
l = lambda f: s.split(_(f),'\n')

# might be running as a standalone, so don't fail if README missing
# (pydoc won't work, but if you're running standalone, it doesn't matter)
try: __doc__ = _('README')
except: pass

