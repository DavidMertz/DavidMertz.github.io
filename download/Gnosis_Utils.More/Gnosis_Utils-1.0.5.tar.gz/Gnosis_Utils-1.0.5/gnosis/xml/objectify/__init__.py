"""Transform XML Documents to Python objects

Please see the information at gnosis.xml.objectify.doc for
explanation of usage, design, license, and other details
"""

from _objectify import *
from _objectify import _XO_
from _printer import XML_printer
