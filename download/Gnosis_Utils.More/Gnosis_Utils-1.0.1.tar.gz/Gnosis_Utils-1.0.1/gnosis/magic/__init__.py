"""Perform black magic of unearthly and ungodly sorts

Quick Example 1:

    Python 2.2 (#0, Dec 24 2001, 18:42:48) [EMX GCC 2.8.1] on os2emx
    Type "help", "copyright", "credits" or "license" for more information.
    >>> import gnosis.magic
    >>> __metaclass__ = gnosis.magic.MetaPickler
    >>> class Boring:
    ...     def __init__(self):
    ...         self.this = 'that'
    ...         self.spam = 'eggs'
    ...     def print_spam(self):
    ...         print self.spam
    ...
    >>> boring = Boring()
    >>> boring.print_spam()
    eggs
    >>> print boring.dumps()
    <?xml version="1.0"?>
    <!DOCTYPE PyObject SYSTEM "PyObjects.dtd">
    <PyObject module="__main__" class="Boring" id="1276364">
    <attr name="this" type="string" value="that" />
    <attr name="spam" type="string" value="eggs" />
    </PyObject>

"""

from gnosis.xml.pickle import dumps

class MetaPickler(type):
    def __init__(cls, name, bases, dict):
        super(MetaPickler, cls).__init__(name, bases, dict)
        setattr(cls, 'dumps', dumps)



