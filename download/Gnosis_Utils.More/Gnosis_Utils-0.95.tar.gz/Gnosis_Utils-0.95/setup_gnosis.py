from distutils.core import setup
import os, sys

def copy2build(root, dirname, names):
    for name in names:
        src = '/'.join([root, dirname, name])
        target = '/'.join([root, 'build', 'lib', dirname, name])
        if os.path.isdir(src):
            try: os.makedirs(target)
            except: pass
        else:
            open(target,'w').write(open(src).read())

if 'install' in sys.argv:
    os.path.walk('gnosis', copy2build, os.getcwd())

setup ( name        = "Gnosis_Utils",
        version     = "0.95",
        description = "Utilities for XML Documents and Other Miscellany",
        author      = "Gnosis Software",
        author_email= "mertz@gnosis.cx",
        url         = "http://gnosis.cx/download/",
        packages    = ["gnosis.xml.pickle", "gnosis.xml.pickle.ext",
                       "gnosis.xml.pickle.util", "gnosis.xml.pickle.doc",
                       "gnosis.xml.pickle.test", "gnosis.xml.pickle.parsers",
                       "gnosis", "gnosis.xml", "gnosis.util",
                       "gnosis.util.convert"
                      ],
        license     = "Public Domain",
      )
