from os import sep
d = sep.join(__file__.split(sep)[:-1])+sep
_ = lambda f: open(d+f).read().rstrip()
l = lambda f: _(f).split('\n')

__doc__ = _('README')

