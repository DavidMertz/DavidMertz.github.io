"Test harness for measuring the speed of different parsers. --fpm"

import gnosis.xml.pickle as xml_pickle
from xml.dom import minidom
from UserList import UserList
from UserDict import UserDict
import re, os
from stat import *
from time import time

def doit3():

    class foo: pass

    f = foo()

    f.a = 1
    f.b = f.a
    f.c = "abc"
    f.d = f.c
    f.r = re.compile('aaa\s+[0-9]*')
    f.r2 = f.r
    l = [1,2,3]
    f.u = UserList([l,l])

    x = xml_pickle.dumps(f)
    print x
    g = thing_from_sax2(None,x)
    print f.u, f.r.pattern, f.r2.pattern
    
def doit2():

    u = UserList([1,2,[(3,4,5),(6,7,8)],3,UserList([0,1,2]),4])

    x = xml_pickle.dumps(u)
    print x
    g = thing_from_sax2(None,x)
    print g
    
def doit():
    class foo: pass

    f = foo()

    # On a pure-speed level, the SAX parser is only
    # about 4x faster than the DOM parser.
    #
    # However, SAX really shines on larger XML files
    # where DOM starts swapping. It's a real fine
    # line between DOM working & hideously swapping,
    # as the examples below show:
    
    # 4-level structure, 1 Mb XML text (20874 elements)
    #
    #    create = 5 secs
    #    minidom.parse() = 71 secs
    #    DOM pickle.load() = 125 secs
    #    SAX pickle.load() = 19 secs
    #    hEXPAT pickle.load() = 0.9 sec
    
    # 5-levels, 7.7 Mb XML text (146113 elements)
    #    create = 34 secs
    #    minidom = runs for hours ... I didn't wait :-)
    #    SAX pickle.load() = 132 secs
    #    hEXPAT pickle.load() = 7.1 secs
    
    # 6-levels, 53 Mb XML text (949836 elements)
    #    create = 218 secs
    #    minidom = I don't think so :-)
    #    SAX pickle.load() = 819 secs
    #    hEXPAT pickle.load() = 43 secs
    
    # 1st level obj
    l = [1,2,3,4,5,6,7,8,9,10]
    t = (1.2,2.3,3.4,4.5,5.6,6.7,7.8,8.9,9.1,10.2)
    d = {'one':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,
         'eight':8,'nine':9,'ten':10}
    c = [(1+2j),(2+3j),(3+4j),(4+5j),(5+6j),(6+7j),(7+8j),(8+9j),(9+10j),(10+11j)]
    s = ('one','two','three','four','five','six','seven','eight','nine','ten')
    
    # 2nd level obj
    ll = [l,l,l,l,l,
          t,t,t,t,t,
          d,d,d,d,d,
          c,c,c,c,c,
          s,s,s,s,s]

    # 3rd level obj
    u = [ll,ll,ll,ll,ll,ll,ll,ll]

    # 4th level
    f.u = [u,u,u,u,u,u,u,u]

    # 5th level
    f.uu = [f.u,f.u,f.u,f.u,f.u,f.u]

    # 6th level
    f.uuu = [f.uu,f.uu,f.uu,f.uu,f.uu,f.uu]
    
    xml_pickle.setDeepCopy(1)
    
    print "CREATE XML"
    t1 = time()
    #fh = open('aaa.xml','w')
    #x = xml_pickle.dump(f,fh)
    #fh.close()
    print "TIME = %f"%(time()-t1)
    print "Pickle len = ",os.stat('aaa.xml')[ST_SIZE]
    
    print "minidom pure parse"
    t1 = time()
    fh = open('aaa.xml','r')
    #minidom.parse(fh)
    fh.close()
    print "TIME = %f"%(time()-t1)

    print "DOM load"
    t1 = time()
    fh = open('aaa.xml','r')
    xml_pickle.setParser("DOM") # default, but just to be sure
    #o = xml_pickle.load(fh)
    fh.close()
    print "TIME = %f"%(time()-t1)
    #del o
    
    print "SAX load"
    t1 = time()
    fh = open('aaa.xml','r')
    xml_pickle.setParser("SAX")
    #m = xml_pickle.load(fh)
    fh.close()
    print "TIME = %f"%(time()-t1)
    #del m
    
    print "hEXPAT load"
    t1 = time()
    fh = open('aaa.xml','r')
    xml_pickle.setParser("hEXPAT")
    m = xml_pickle.load(fh)
    fh.close()
    print "TIME = %f"%(time()-t1)       
    del m
    
doit()




