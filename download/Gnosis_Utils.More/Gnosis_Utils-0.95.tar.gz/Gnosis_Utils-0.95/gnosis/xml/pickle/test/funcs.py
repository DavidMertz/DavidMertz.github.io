
"""
each test_*.py imports this to auto-set the parser based on
the presence of a USE_... file

-- frankm@hiwaay.net
"""

import os
import gnosis.xml.pickle as xml_pickle

# set parser based on USE_... file present
def set_parser():
    if os.path.isfile('USE_SAX'):
        xml_pickle.setParser("SAX")
    elif os.path.isfile('USE_HEXPAT'):
        xml_pickle.setParser('hEXPAT')
    else:
        xml_pickle.setParser('DOM')

