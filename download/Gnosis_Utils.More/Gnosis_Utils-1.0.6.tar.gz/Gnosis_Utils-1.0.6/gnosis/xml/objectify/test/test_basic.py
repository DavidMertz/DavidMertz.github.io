"Read and print and objectified XML file"

import sys
from gnosis.xml.objectify import XML_Objectify, pyobj_printer

if len(sys.argv) > 1:
    for filename in sys.argv[1:]:
        xml_obj = XML_Objectify(filename)
        py_obj = xml_obj.make_instance()
        print pyobj_printer(py_obj).encode('UTF-8')
else:
    print "Please specify one or more XML files to Objectify."


