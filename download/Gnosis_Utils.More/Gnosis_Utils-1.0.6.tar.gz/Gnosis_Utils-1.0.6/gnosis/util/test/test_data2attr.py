if version >= '2.2':
    class NewList(list): pass
    class NewTuple(tuple): pass
    class NewDict(dict): pass

    nl = NewList([1,2,3])
    nt = NewTuple([1,2,3])
    nd = NewDict({1:2,3:4})
    nl.attr = 'spam'
    nt.attr = 'spam'
    nd.attr = 'spam'

    nl = data2attr(nl)
    print nl, nl.__items__
    nl = attr2data(nl)
    print nl, getattr(nl, '__items__', 'No __items__')

    nt = data2attr(nt)
    print nt, nt.__items__
    nt = attr2data(nt)
    print nt, getattr(nt, '__items__', 'No __items__')

    nd = data2attr(nd)
    print nd, nd.__entries__
    nd = attr2data(nd)
    print nd, getattr(nd, '__entries__', 'No __entries__')
else:
    print "data2attr() and attr2data() only work on 2.2+ new-style objects"


