
"""

Here are collected miscellaneous tests (from bug reports,etc.)
that don't clearly fit elsewhere. --fpm

"""

import gnosis.xml.pickle as xml_pickle  
from funcs import set_parser, pyver

set_parser()

# this is from a bug report from Even Westvang <even@bengler.no>.
# the problem is that new-style classes used as attributes weren't
# being pickled correctly.

if pyver() >= '2.2': # new-style classes introduced in 2.2
    class PickleMeOld:
        def __init__(self): pass

    class PickleMeNew(object):
        def __init__(self): pass

    class Container(object):
        def __init__(self, klass):
            self.classRef = klass

    print xml_pickle.dumps(Container(PickleMeOld))
    print xml_pickle.dumps(Container(PickleMeNew))
