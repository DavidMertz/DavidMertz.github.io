__doc__ = """Convert "smart ASCII" documents to other formats"""

